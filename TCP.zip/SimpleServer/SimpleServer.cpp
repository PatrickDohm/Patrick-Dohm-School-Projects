#include <iostream>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string>
#include <unistd.h>
#include <ctime>
#include <sys/time.h>
#include <sstream>

using namespace std;

int port = 62500;

void error(const char *msg)
{
    perror(msg);
    exit(1);
}


int main()
{
   
    int opt=true;
    int SocketD;
   int max_sd, sd, activity;
    int new_socket;
    int client_socket[30], max_clients=30;
    // create a socket
    // socket(int domain, int type, int protocol)
    SocketD = socket(AF_INET,SOCK_STREAM,0);
    if (SocketD < 0)
        error("ERROR opening socket");
    else{
        cout << "My Socket Descriptor:"  << SocketD <<endl;
        }
        
    struct sockaddr_in self;
    //set of Socket Descriptors
    fd_set readfds;
    //initialize all client_socket[] to 0 so not checked
    for(int i=0;i<max_clients;i++){
        client_socket[i]=0;
    }

    //set SocketD to allow multiple connections
    if(setsockopt(SocketD,SOL_SOCKET,SO_REUSEADDR, (char *)&opt,sizeof(opt))<0){
        error("setsockopt");
    }


    // clear address structure
    bzero ((char *) &self, sizeof(self));
    /* setup the host_addr structure for use in bind call */
    // server byte order
    self.sin_family = AF_INET;
    // convert short integer value for port must be converted into network byte order
    self.sin_port = htons(port);
    // automatically be filled with current host's IP address
    self.sin_addr.s_addr = INADDR_ANY;
     // bind(int fd, struct sockaddr *local_addr, socklen_t addr_length)
     // bind() passes file descriptor, the address structure,
     // and the length of the address structure
     // This bind() call will bind  the socket to the current IP address on port, portno
    if(bind(SocketD,(struct sockaddr*)&self,sizeof(self)) < 0 )
        error("Error On Binding");
    // This listen() call tells the socket to listen to the incoming connections.
    // The listen() function places all incoming connection into a backlog queue
    // until accept() call accepts the connection.
    // Here, we set the maximum size for the backlog queue to 20.
    listen(SocketD,20);
    cout << "Server is listening on port: " << port <<endl;
    struct sockaddr_in client_addr;
    // clear address structure
    bzero ((char *) &client_addr, sizeof(client_addr));
    int addrlen = sizeof(client_addr);
    // This accept() function will write the connecting client's address info
    // into the the address structure and the size of that structure is clilen.
    // The accept() returns a new socket file descriptor for the accepted connection.
    // So, the original socket file descriptor can continue to be used
    // for accepting new connections while the new socker file descriptor is used for
    // communicating with the connected client.
    while(true){
        //clear the socket set
        FD_ZERO(&readfds);

        //add SocketD to set
        FD_SET(SocketD,&readfds);
        max_sd=SocketD;

        //add child sockets to set
        for(int i=0;i<max_clients;i++){
            sd=client_socket[i];
            //if valid socket descriptor then add to read list
            if(sd>0){
                FD_SET(sd,&readfds);
            }
            //highest file descriptor number, need it for select()
            if(sd>max_sd){
                max_sd=sd;
            }
        }

        //wait indefinietly for activity on socket
        activity=select(max_sd+1, &readfds,NULL,NULL,NULL);
        if((activity<0) && (errno !=EINTR)){
            error("select error");
        }

        //if(something happens on SocketD, then its an incoming connection)
        if(FD_ISSET(SocketD,&readfds)){
            if((new_socket=accept(SocketD,(struct sockaddr*)&client_addr,(socklen_t*)&addrlen))<0){
                error("accept error");
            }

            //send Hello Mom
             string Hello = "Hello. Please Enter fortune, lucky, disconnect, or exit";

            send(new_socket,Hello.c_str(),Hello.length(),0);
            //add new socket to array of sockets
            for(int i=0;i<max_clients;i++){
                if(client_socket[i]==0){
                    client_socket[i]=new_socket;
                    cout<< "adding to list of sockets as: "+to_string(i)<<endl;
                    break;
                }
            }
        }
        char rebuffer[80];
        bzero(rebuffer, sizeof(rebuffer));
        //else its some io operation on some other socket
        for(int i=0;i<max_clients;i++){
            sd=client_socket[i];
            if(FD_ISSET(sd,&readfds)){
                int received=0;
                received=recv(sd, rebuffer, 80, 0);
                string arr="";
                arr=(string)rebuffer;
                bzero(rebuffer, sizeof(rebuffer));
                if(arr=="disconnect\n"){
                    arr="You have been disconnected";
                    send(sd,arr.c_str(),arr.length(),0);
                    close(sd);
                    client_socket[i]=0;
                }else if(arr=="fortune\n"){
                   char* args[]={"fortune",NULL};
                    cout <<"Selecting a fortune"<<endl;
                    stringstream buffer;
                    streambuf* old=cout.rdbuf(buffer.rdbuf());
                    execvp(args[0],args);
                    cout << "fortune selected"<<endl;
                    string fortune= buffer.str();
                    send(sd, fortune.c_str(), fortune.length(),0);
                    cout.rdbuf(old);
                    cout<<"fortune sent"<<endl;

                
                }else if(arr== "lucky\n"){
                    string range="pick a maximum value";
                    send(sd,range.c_str(),range.length(),0);
                    received=recv(sd, rebuffer,80,0);
                    int max_range= atoi(rebuffer);
                    range="pick a minimum value";
                    send(sd,range.c_str(), range.length(), 0);
                     bzero(rebuffer, sizeof(rebuffer));
                      received=recv(sd, rebuffer,80,0);
                    int min_range=atoi(rebuffer);
                    srand((unsigned) time(0));
                    int luckyNumber=(rand()%max_range+min_range);//return a number between the max and min
                    arr="Your lucky number is " +to_string(luckyNumber)+". Enter fortune or lucky to play again";
                    send(sd, arr.c_str(),arr.length(),0);
                }else if(arr=="exit\n"){
                    string end="disconnect\n";
                    cout<<end<<endl;
                    send(sd, end.c_str(),end.length(),0);
                    close(SocketD);
                }else{
                    string invalid="Invalid command, Enter fortune, lucky, disconnect, or exit";
                    send(sd, invalid.c_str(),invalid.length(),0);
                }
            }
        }
    }
    return 0;
}