//Patrick Dohm
//cs475 Networks
//Simple Client

//The goal is to write a simple client that runs off of the command line

#include <iostream>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

using namespace std;
void error(const char *msg){
    perror(msg);
    exit(1);
}

int main (int argc, char *argv[]){
    //get the values from the command line
    const char* url= argv[1]; //csserver.evansville.edu
    int port=atoi(argv[2]);//62500
    int SocketD;
    //create a socket
    //socket(int domain, int type, int protocol)
    SocketD=socket(AF_INET, SOCK_STREAM, 0);
    if(SocketD<0){
        error("ERROR Opening socket");
    }else{
        cout<<"My Socket Descriptor:"<<SocketD<<endl;
    }

    struct sockaddr_in server_addr;
    struct hostent *hp=gethostbyname(url);
    //clear address structure
    bzero((char *) &server_addr, sizeof(server_addr));
    //server byte order
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(port);
    server_addr.sin_addr.s_addr=*((unsigned long *)hp->h_addr) ;

    //Connect to server
    if(connect(SocketD,(struct sockaddr *)&server_addr, sizeof(server_addr))<0){
        error("Error connecting");
    }
    cout<<"Successfully Connected"<<endl;

   
    bool disconnect=false;
    while(!disconnect){
       
        int received=0;
        char rebuffer[80];
      
            received=recv(SocketD, rebuffer, 80,0);
            if(received<0){
                error("failed to recieve message");
            }
            string msgR= string(rebuffer);
            cout<<"MSG Recieved"<<endl;
            cout<<msgR<<endl;
            bzero(rebuffer, sizeof(rebuffer));//clear out buffer
           
        
        //sending msg
        string msg;
        msg.clear();
        getline(cin,msg);
        msg=msg+'\n';
        cout<<"Sending msg: "<<msg<<endl;
        send(SocketD, msg.c_str(),msg.length(),0);
        cout<<"MSG sent"<<endl;
        //Disconnect
        if(msg=="exit\n"){
            msg="disconnect\n";
        }
        if(msg=="disconnect\n"){
            disconnect=true;
        }else{
            cout<<"MSG != disconnect"<<endl;
       
        }
        
        


    }

    cout<<"Disconnecting"<<endl;
    close(SocketD);
    return 0;


}