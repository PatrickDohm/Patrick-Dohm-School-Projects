﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.ComponentModel;
using System.Diagnostics;

namespace Fractals
{

    public partial class MainWindow : Window
    {
        private WriteableBitmap wbmap_fractal_1;
        private WriteableBitmap wbmap_fractal_2;
        private WriteableBitmap wbmap_fractal_3;
        private WriteableBitmap wbmap_fractal_4;
        private WriteableBitmap wbmap_fractal_5;
        private WriteableBitmap wbmap_fractal_6;
        private WriteableBitmap wbmap_fractal_7;
        private WriteableBitmap wbmap_fractal_8;
        static BackgroundWorker bkw1 = new BackgroundWorker();//initializing background workers
        static BackgroundWorker bkw2 = new BackgroundWorker();
        static BackgroundWorker bkw3 = new BackgroundWorker();
        static BackgroundWorker bkw4 = new BackgroundWorker();
        static BackgroundWorker bkw5 = new BackgroundWorker();
        static BackgroundWorker bkw6 = new BackgroundWorker();
        static BackgroundWorker bkw7 = new BackgroundWorker();
        static BackgroundWorker bkw8 = new BackgroundWorker();
        private double Xworld_Max = 3.0;            //the screen values need to be constant because the image dimensions do not change
        private double Xworld_Min = -3.0;           //the world values cant be constant because the zoom button will change them.
        const double Xscreen_Max = 508;
        const double Xscreen_Min = 0;
        const double Yscreen_Max = 312;
        const double Yscreen_Min = 0;
        private double Yworld_Max = 1.25;
        private double Yworld_Min = -1.25;
        private double Xworld_center = 0;
        private double Yworld_center = 0;
        const int array_size = 65;
        private int MAX = 5;
        private int MAX_COUNT = 64;
        private double xworld;
        private double yworld;
        Color[] color_array = new Color[array_size];
        private double qx = 3;
        private double qy = 0;

        private bool julia = false;
        public MainWindow()
        {
            InitializeComponent();
            wbmap_fractal_1 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_2 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_3 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_4 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_5 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_6 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_7 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            wbmap_fractal_8 = new WriteableBitmap(127, 156, 300, 300, PixelFormats.Bgra32, null);
            color_array[0] = Color.FromArgb(255, 0, 1, 6);            //assigning each number in the color array
            color_array[1] = Color.FromArgb(255, 5, 35, 6);
            color_array[2] = Color.FromArgb(255, 10, 85, 6);
            color_array[3] = Color.FromArgb(255, 15, 100, 26);
            color_array[4] = Color.FromArgb(255, 20, 153, 6);
            color_array[5] = Color.FromArgb(255, 25, 153, 6);
            color_array[6] = Color.FromArgb(255, 30, 153, 6);
            color_array[7] = Color.FromArgb(255, 35, 153, 58);
            color_array[8] = Color.FromArgb(255, 40, 153, 6);
            color_array[9] = Color.FromArgb(255, 45, 153, 6);
            color_array[10] = Color.FromArgb(255, 50, 153, 6);
            color_array[11] = Color.FromArgb(255, 55, 153, 6);
            color_array[12] = Color.FromArgb(255, 60, 153, 6);
            color_array[13] = Color.FromArgb(255, 65, 153, 6);
            color_array[14] = Color.FromArgb(255, 70, 153, 6);
            color_array[15] = Color.FromArgb(255, 75, 153, 6);
            color_array[16] = Color.FromArgb(255, 18, 189, 6);
            color_array[17] = Color.FromArgb(255, 85, 153, 6);
            color_array[18] = Color.FromArgb(255, 90, 153, 6);
            color_array[19] = Color.FromArgb(255, 95, 153, 6);
            color_array[20] = Color.FromArgb(255, 100, 153, 6);
            color_array[24] = Color.FromArgb(255, 105, 153, 6);
            color_array[28] = Color.FromArgb(255, 110, 153, 6);
            color_array[29] = Color.FromArgb(255, 115, 153, 6);
            color_array[30] = Color.FromArgb(255, 120, 153, 6);
            color_array[31] = Color.FromArgb(255, 125, 153, 6);
            color_array[32] = Color.FromArgb(255, 130, 15, 106);
            color_array[33] = Color.FromArgb(255, 135, 153, 6);
            color_array[34] = Color.FromArgb(255, 140, 153, 6);
            color_array[35] = Color.FromArgb(255, 145, 153, 6);
            color_array[36] = Color.FromArgb(255, 150, 153, 6);
            color_array[37] = Color.FromArgb(255, 155, 153, 6);
            color_array[38] = Color.FromArgb(255, 160, 153, 6);
            color_array[39] = Color.FromArgb(255, 165, 153, 6);
            color_array[40] = Color.FromArgb(255, 170, 153, 6);
            color_array[41] = Color.FromArgb(255, 175, 153, 6);
            color_array[42] = Color.FromArgb(255, 180, 153, 6);
            color_array[43] = Color.FromArgb(255, 185, 153, 6);
            color_array[44] = Color.FromArgb(255, 190, 153, 6);
            color_array[45] = Color.FromArgb(255, 195, 153, 6);
            color_array[46] = Color.FromArgb(255, 200, 153, 6);
            color_array[47] = Color.FromArgb(255, 205, 153, 6);
            color_array[48] = Color.FromArgb(255, 210, 153, 6);
            color_array[49] = Color.FromArgb(255, 215, 153, 6);
            color_array[50] = Color.FromArgb(255, 220, 153, 6);
            color_array[51] = Color.FromArgb(255, 225, 153, 6);
            color_array[52] = Color.FromArgb(255, 230, 153, 6);
            color_array[53] = Color.FromArgb(255, 235, 153, 6);
            color_array[54] = Color.FromArgb(255, 240, 153, 6);
            color_array[55] = Color.FromArgb(255, 245, 153, 6);
            color_array[56] = Color.FromArgb(255, 250, 153, 6);
            color_array[57] = Color.FromArgb(255, 250, 0, 6);
            color_array[58] = Color.FromArgb(255, 250, 5, 6);
            color_array[59] = Color.FromArgb(255, 250, 10, 6);
            color_array[60] = Color.FromArgb(255, 250, 15, 6);
            color_array[61] = Color.FromArgb(255, 250, 20, 6);
            color_array[62] = Color.FromArgb(255, 250, 25, 6);
            color_array[63] = Color.FromArgb(255, 250, 30, 6);
            color_array[64] = Color.FromArgb(255, 250, 35, 6);



        }

        private void Start_btn_Click(object sender, RoutedEventArgs e)//assign each background worker to a quadrant and waits for them to be done.
        {


            bkw1.DoWork += new DoWorkEventHandler(DoWorkMethod1);    //sets what each thread does           
            bkw2.DoWork += new DoWorkEventHandler(DoWorkMethod2);
            bkw3.DoWork += new DoWorkEventHandler(DoWorkMethod3);
            bkw4.DoWork += new DoWorkEventHandler(DoWorkMethod4);
            bkw5.DoWork += new DoWorkEventHandler(DoWorkMethod5);
            bkw6.DoWork += new DoWorkEventHandler(DoWorkMethod6);
            bkw7.DoWork += new DoWorkEventHandler(DoWorkMethod7);
            bkw8.DoWork += new DoWorkEventHandler(DoWorkMethod8);
            bkw1.RunWorkerAsync();//tells the workers to run
            bkw2.RunWorkerAsync();
            bkw3.RunWorkerAsync();
            bkw4.RunWorkerAsync();
            bkw5.RunWorkerAsync();
            bkw6.RunWorkerAsync();
            bkw7.RunWorkerAsync();
            bkw8.RunWorkerAsync();//waits until all the threads are finished
                                  //display the entire fractal when they are all finished
        }
        private Complex Screen_to_World_1(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;


            return c;

        }
        private Complex Screen_to_World_2(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_3(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_4(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_5(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_6(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_7(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        private Complex Screen_to_World_8(double xscreen, double yscreen) //sets the xworld and yworld component
        {
            Complex c = new Complex();
            xworld = (xscreen) * ((Xworld_Max - Xworld_Min) / (Xscreen_Max - Xscreen_Min)) + (Xworld_center - Xworld_Min) - (Xworld_Max - Xworld_Min);
            yworld = -(yscreen) * ((Yworld_Max - Yworld_Min) / (Yscreen_Max - Yscreen_Min)) + (Yworld_center - Yworld_Min);
            c.Real = xworld;
            c.Imag = yworld;
            return c;

        }
        //this is how the background workers are assigned
        // * *  *  *  *  *
        // * 1  2  3  4  *
        // * 5  6  7  8  *
        // * *  *  *  *  *
        private void DoWorkMethod1(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_1(0, 0, 172, 127);//does mendle fractal

                Img_1.Source = wbmap_fractal_1;
            });

        }
        private void DoWorkMethod2(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_2(0, 128, 172, 256);
                Img_2.Source = wbmap_fractal_2;
            });

        }
        private void DoWorkMethod3(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_3(0, 257, 172, 384);
                Img_3.Source = wbmap_fractal_3;
            });
        }
        private void DoWorkMethod4(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_4(0, 385, 172, 511);

                Img_4.Source = wbmap_fractal_4;
            });

        }
        private void DoWorkMethod5(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_5(173, 0, 343, 127);

                Img_5.Source = wbmap_fractal_5;
            });

        }
        private void DoWorkMethod6(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_6(173, 128, 343, 256);

                Img_6.Source = wbmap_fractal_6;
            });


        }
        private void DoWorkMethod7(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_7(173, 257, 343, 384);

                Img_7.Source = wbmap_fractal_7;
            });


        }
        private void DoWorkMethod8(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                assign_color_8(173, 385, 343, 511);

                Img_8.Source = wbmap_fractal_8;
            });

        }
        private void assign_color_1(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {//all duplicates of this are so threads dont occupy the same function and crash each other

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_1(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_1(wbmap_fractal_1, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }

        private void assign_color_2(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_2(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    if (julia == true)
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;


                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_2(wbmap_fractal_2, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }

        }
        private void assign_color_3(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_3(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;


                    //each color is hardcoded
                    SetPixel_3(wbmap_fractal_3, x - min_screen_width, y - min_screen_height, color_array[colorNum]);   //C) write the color to that pixel in the bitmap
                                                                                                                       //subtract from x to get the data for the proper bitmap

                }
            }
        }
        private void assign_color_4(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_4(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_4(wbmap_fractal_4, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }
        private void assign_color_5(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_5(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_5(wbmap_fractal_5, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }
        private void assign_color_6(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_6(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex z1 = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_6(wbmap_fractal_6, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }
        private void assign_color_7(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_7(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_7(wbmap_fractal_7, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }
        private void assign_color_8(int min_screen_height, int min_screen_width, int scrHeight, int scrWidth)//taken from the fractals pdf we were given
        {

            for (int y = min_screen_height; y < scrHeight; y++) //Im using min_screen_height so i can call this function with each background worker
            {
                for (int x = min_screen_width; x < scrWidth; x++)
                {
                    Complex c = new Complex(x, y);
                    c = Screen_to_World_8(x, y);  //A) translate the pixel to real world coordinates
                    Complex q = new Complex(qx, qy);
                    int count = 0; Complex z = new Complex();
                    Complex zn = new Complex();
                    zn = Screen_to_World_8(x, y);
                    Complex z1 = new Complex();
                    if (julia == false)
                    { //Mendle Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = z * z + c;//taken from the fractals pdf
                            z = z1;
                            count++;
                        }
                    }
                    else
                    {//Julia Fractal
                        while (count < MAX_COUNT && z.Mag() < MAX) //B) apply rules of the fractal to arrive at a color number
                        {
                            z1 = zn * zn + q;//taken from the fractals pdf
                            zn = z1;
                            count++;
                        }

                    }
                    int colorNum = count % 64;
                    Color m;

                    m = color_array[colorNum];  //each color is hardcoded
                    SetPixel_8(wbmap_fractal_8, x - min_screen_width, y - min_screen_height, m);   //C) write the color to that pixel in the bitmap
                                                                                                   //subtract from x to get the data for the proper bitmap

                }
            }
        }
        public void SetPixel_1(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_1(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }
        public void SetPixel_2(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_2(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_3(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_3(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_4(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_4(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_5(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_5(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_6(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_6(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_7(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_7(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        public void SetPixel_8(WriteableBitmap wbm, int x, int y, Color c)//sets a single pixel in the fractal
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            if (!wbm.Format.Equals(PixelFormats.Bgra32)) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }
        public Color GetPixel_8(WriteableBitmap wbm, int x, int y)//returns a color of a pixel in the bitmap
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            if (!wbm.Format.Equals(PixelFormats.Bgra32))
                return Color.FromArgb(0, 0, 0, 0); ;
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }












        private void Zoom_btn_Click(object sender, RoutedEventArgs e)//meant to zoom
        {
            Xworld_Min = Xworld_Min + .2;
            Yworld_Min = Yworld_Min + .2;
            Xworld_Max = Xworld_Max - .2;
            Yworld_Max = Yworld_Max - .2;
            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates
        }

        private void Iteration_10_Click(object sender, RoutedEventArgs e)//increases the number of iterations by increasing the z.mag()
        {
            MAX = MAX + 10;

        }

        private void Iteration_subtract_10_Click(object sender, RoutedEventArgs e)//decreases the number of iterations by decreasing the z.mag()
        {
            MAX = MAX - 10;

        }

        private void Julia_Click(object sender, RoutedEventArgs e)//makes the julia fractal
        {

            julia = true;
            Start_btn_Click(this, null);

        }

        private void Move_center_up_Click(object sender, RoutedEventArgs e)//moves the centerpoint up
        {

            Yworld_Min = Yworld_Min + .2;

            Yworld_Max = Yworld_Max + .2;
            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates
        }

        private void Zoom_out_Click(object sender, RoutedEventArgs e)
        {
            Xworld_Min = Xworld_Min - .2;
            Yworld_Min = Yworld_Min - .2;
            Xworld_Max = Xworld_Max + .2;
            Yworld_Max = Yworld_Max + .2;
            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates

        }

        private void Move_center_down_Click(object sender, RoutedEventArgs e)
        {
            Yworld_Min = Yworld_Min - .2;

            Yworld_Max = Yworld_Max - .2;

            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates

        }

        private void Move_center_left_Click(object sender, RoutedEventArgs e)
        {
            Xworld_Min = Xworld_Min - .2;

            Xworld_Max = Xworld_Max - .2;
            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates

        }

        private void Move_center_right_Click(object sender, RoutedEventArgs e)
        {
            Xworld_Min = Xworld_Min + .2;

            Xworld_Max = Xworld_Max + .2;
            Start_btn_Click(this, null);//runs and redraws the fractal with the zoomed in coordinates
        }
    }
}
