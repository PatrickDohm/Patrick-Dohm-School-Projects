﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Fractals 
{
    class Complex
    {
        public Complex()
        {
            Real = 0;
            Imag = 0;
        }
        public Complex(double x, double y)
        {
            Real = x;
            Imag = y;
        }
        public double Real { get; set; } //Real property
        public double Imag { get; set; } //Imag property
                                         /// <summary>
                                         /// Allows z = z1 + z2 for complext variables
                                         /// </summary>
                                         /// <param name="x"></param>
                                         /// <param name="y"></param>
                                         /// <returns></returns>
        public static Complex operator +(Complex x, Complex y)
        {
            Complex cTmp = new Complex();
            cTmp.Real = x.Real + y.Real;
            cTmp.Imag = x.Imag + y.Imag;
            return cTmp;
        }
        /// <summary>
        /// Allows z = z1 * z2 for complex variables
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static Complex operator *(Complex x, Complex y)
        {
            Complex cTmp = new Complex();
            cTmp.Real = x.Real * y.Real - x.Imag * y.Imag;
            cTmp.Imag = x.Imag * y.Real + y.Imag * x.Real;
            return cTmp;
        }
        /// <summary>
        /// Returns the magnitude of the complex number
        /// </summary>
        /// <returns></returns>
        public double Mag()
        {
            return Math.Sqrt(Real * Real + Imag * Imag);
        }
    }
}