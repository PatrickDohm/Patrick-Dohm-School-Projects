import java.util.Scanner;

import static java.lang.System.exit;

public class GameSelection {

    public static void main(String args[]){
        System.out.println("Press 1 for Connect 4, Press 2 for Gomoku, Press 3 for checkers, Press 4 for Chess");
        Scanner sc = new Scanner(System.in);
        String input="";
        input=sc.nextLine();

        if(input.contains("1")){
            PlayConnect4 game=new PlayConnect4();
            game.StartConnect4();
            exit(0);
        }else if(input.contains("2")){
            PlayGomoku game= new PlayGomoku();
            game.StartGomuku();
        }else if(input.contains("3")){
            PlayCheckers game= new PlayCheckers();
            game.StartCheckers();
        }else if(input.contains("4")){
            PlayChess game= new PlayChess();
            game.StartChess();
        }

    }
}
