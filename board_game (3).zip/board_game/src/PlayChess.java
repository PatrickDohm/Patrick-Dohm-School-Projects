import java.util.Scanner;

public class PlayChess extends Play {
    int row=8;
    int column=8;
    ChessBoard board1;
    Scanner sc;
    public PlayChess(){
        board1=new ChessBoard();

        sc=new Scanner(System.in);
    }

    public void StartChess() {
        row_column original= new row_column();
        row_column change= new row_column();
        String input;
        while(board1.isWinner(playerTurn,0,0)==false){
            original.setPlayerTurn(playerTurn);
            change.setPlayerTurn(playerTurn);
            board1.printBoard();
            printPlayerTurn();

            int tempRow;
            int tempColumn;
            try {
                input = sc.nextLine();
                //input should look like A4-B5
                tempColumn=board1.convertColumnToNumber(input.charAt(0));
                tempRow=board1.ConvertRow(Character.getNumericValue(input.charAt(1)));
                original.setColumn(tempColumn);
                original.setRow(tempRow);
                tempColumn=board1.convertColumnToNumber(input.charAt(3));
                tempRow=board1.ConvertRow(Character.getNumericValue(input.charAt(4)));
                change.setRow(tempRow);
                change.setColumn(tempColumn);
                if(board1.movePiece(original,change)){
                    //check for pawn promotion
                    if(change.getPlayerTurn()==1){
                        for(int i=0;i<8;i++){
                            if(board1.board1[7][i].getPlayerPiece()=='p'){
                                System.out.println("Press 1 to promote to Queen");
                                System.out.println("Press 2 to promote to Rook");
                                System.out.println("Press 3 to promote to bishop");
                                System.out.println("Press 4 to promote to knight");
                                input="";
                                while(!input.contains("1") && !input.contains("2") && !input.contains("3") && !input.contains("4") ){
                                    input=sc.nextLine();
                                    if(input.contains("1")){
                                        board1.board1[7][i].setPlayerPiece('q');
                                    }else if(input.contains("2")){
                                        board1.board1[7][i].setPlayerPiece('r');
                                    }else if(input.contains("3")){
                                        board1.board1[7][i].setPlayerPiece('b');
                                    }else if(input.contains("4")){
                                        board1.board1[7][i].setPlayerPiece('n');
                                    }
                                }

                            }
                        }
                    }else if(change.getPlayerTurn()==2){
                        for(int i=0;i<8;i++){
                            if(board1.board1[0][i].getPlayerPiece()=='P'){
                                System.out.println("Press 1 to promote to Queen");
                                System.out.println("Press 2 to promote to Rook");
                                System.out.println("Press 3 to promote to bishop");
                                System.out.println("Press 4 to promote to knight");
                                input="";
                                while(!input.contains("1") && !input.contains("2") && !input.contains("3") && !input.contains("4") ){
                                    input=sc.nextLine();
                                    if(input.contains("1")){
                                        board1.board1[7][i].setPlayerPiece('Q');
                                    }else if(input.contains("2")){
                                        board1.board1[7][i].setPlayerPiece('R');
                                    }else if(input.contains("3")){
                                        board1.board1[7][i].setPlayerPiece('B');
                                    }else if(input.contains("4")){
                                        board1.board1[7][i].setPlayerPiece('N');
                                    }
                                }

                            }
                        }
                    }
                    board1.inCheck(original);
                    changePlayerTurn();
                }

           }catch(IllegalArgumentException e){
                System.out.println(e);
            }

        }
        changePlayerTurn();
        System.out.println("Player "+playerTurn + " won");
        System.exit(0);

    }
}
