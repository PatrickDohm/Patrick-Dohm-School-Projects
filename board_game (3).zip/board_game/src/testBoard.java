import org.junit.Assert;
import org.junit.Test;

public class testBoard {
    @Test
    public void testConnect4Board(){
        //make blank board
        Connect4_Board board= new Connect4_Board();
        for(int i=0;i<6;i++){
            Assert.assertEquals(board.getSquare(i,'A').isEmpty(), true);
            Assert.assertEquals(board.getSquare(i,'B').isEmpty(), true);
            Assert.assertEquals(board.getSquare(i,'C').isEmpty(), true);
            Assert.assertEquals(board.getSquare(i,'D').isEmpty(), true);
            Assert.assertEquals(board.getSquare(i,'E').isEmpty(), true);
            Assert.assertEquals(board.getSquare(i,'F').isEmpty(), true);
        }


        board.placePiece(0,0,0);

        board.placePiece(1,0,0);

        Assert.assertEquals(board.isWinner(1,5,0), false);
        board.placePiece(0,0,1);
        board.placePiece(0,0,2);
        board.placePiece(0,0,3);


        Assert.assertEquals(board.isWinner(0,5,0),true);
    }

    @Test
    public void testGomoku(){
        Gomoku_Board board= new Gomoku_Board();

        board.placePiece(0,2,3);
        board.printBoard();
    }

    @Test
    public void testCheckers(){
        checkers_board board= new checkers_board();
        board.printBoard();
    }

    @Test
    public void testChess(){
        ChessBoard board= new ChessBoard();

        board.printDummyBoard();
    }
}
