public class Play {
    int playerTurn=1;
    protected void changePlayerTurn(){
        if(playerTurn==1){
            playerTurn=2;
        }else{
            playerTurn=1;
        }
    }
    protected void printPlayerTurn(){
        System.out.println("\n");
        if(playerTurn==1){
            System.out.println("Its Player 1's Turn");
        }else{
            System.out.println("Its Player 2's Turn");
        }
    }
}
