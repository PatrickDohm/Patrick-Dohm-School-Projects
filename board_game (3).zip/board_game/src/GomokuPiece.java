public class GomokuPiece extends Piece {
    public GomokuPiece(){
        super.playerPiece='*';
    }
}
