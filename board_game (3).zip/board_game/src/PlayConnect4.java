import java.util.Scanner;

public class PlayConnect4 extends Play {
    Connect4_Board board;

    Scanner sc;
    public void StartConnect4(){
        Connect4Init();
        board.printBoard();
        System.out.println("Welcome to Connect 4");
        PlayGame();

    }

    private void Connect4Init() {
        board= new Connect4_Board();
        playerTurn=1;
        sc=new Scanner(System.in);
    }

    private void PlayGame(){
        int column=0;
        int row=0;
        do{
            board.printBoard();
            changePlayerTurn();
            printPlayerTurn();
            System.out.println("Type the letter of the column you want to place your piece in");
            String input=sc.nextLine();
            try {
                 column = board.convertColumnToNumber(input.charAt(0));
                 row=board.placePiece(playerTurn, 0, column);
            }catch(IllegalArgumentException e){
                System.out.println("Need to pick a letter between a and g");
                changePlayerTurn(); //if they make an illegal move then they get to play again
            }catch(IllegalStateException e){
                System.out.println("That column is Full");
                changePlayerTurn();
            }




        }while(board.isWinner(playerTurn, row,column)==false);
    }


}
