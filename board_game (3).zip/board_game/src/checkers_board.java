public class checkers_board extends AbstractBoard  {

    protected CheckersPiece board1[][];
    public checkers_board(){
        boolean black=true;
        super.row=8;
        super.column=8;
        board= new CheckersPiece[row][column];
         board1=(CheckersPiece[][])board;

         for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                board1[i][j]=new CheckersPiece();
                if (black) {
                    board1[i][j].setBlack();
                }

                black=!black;
            }
            black=!black;
        }
         starting_board();
    }

    public void starting_board(){
        for(int j=0; j<row;j++){
            for(int i=0;i<3;i++){
                if(board1[i][j].getBlack()){
                    board1[i][j].setPlayerPiece('w');
                }
            }
            for(int i=5;i<column;i++){
                if(board1[i][j].getBlack()){
                    board1[i][j].setPlayerPiece('r');
                }
            }
        }





    }

    @Override
    protected int placePiece(int playerTurn, int row, int column) {
        return 0;
    }

    @Override
    protected int possibleMove(row_column current ){//will print the tile as with a lowercase letter and the piece that makes the move with an uppercase
        int numberJumps=0;
        char c;
        char d;
        c=convertPlayerTurnToPieceLetter(current);

        if(c=='r' || c=='R'){
            d='w';
        }else{
            d='r';
        }


        //checking jumps
        //if a jump at that square is possible, set the square and the jump square
        //increment the number jumps

        //the piece is a king
        if(board1[current.getRow()][current.getColumn()].isKing()
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()-1>0
                    && current.getColumn()-1>0
                    && Character.toLowerCase(board1[current.getRow()-1][current.getColumn()-1].getPlayerPiece())==d
                    && board1[current.getRow()-2][current.getColumn()-2].isEmpty()){

                        board1[current.getRow()-2][current.getColumn()-2].setPlayerPiece('p');
                        board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                        numberJumps++;
            }
            if(current.getRow()-1>0
                    &&current.getColumn()+1<7
                    &&Character.toLowerCase(board1[current.getRow()-1][current.getColumn()+1].getPlayerPiece())==d
                    && board1[current.getRow()-2][current.getColumn()+2].isEmpty()){

                board1[current.getRow()-2][current.getColumn()+2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
            if(current.getRow()+1<7
                    &&current.getColumn()+1<7
                    &&Character.toLowerCase(board1[current.getRow()+1][current.getColumn()+1].getPlayerPiece())==d
                    && board1[current.getRow()+2][current.getColumn()+2].isEmpty()){

                board1[current.getRow()+2][current.getColumn()+2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
            if(current.getRow()+1<7
                    &&current.getColumn()-1>0
                    &&Character.toLowerCase(board1[current.getRow()+1][current.getColumn()-1].getPlayerPiece())==d
                    && board1[current.getRow()+2][current.getColumn()-2].isEmpty()){

                board1[current.getRow()+2][current.getColumn()-2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }

        }
        //if the the piece is red and not a king
        if(c=='r'
                && board1[current.getRow()][current.getColumn()].isKing()==false
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()-2>=0
                    &&current.getColumn()-2>=0
                    && Character.toLowerCase(board1[current.getRow()-1][current.getColumn()-1].getPlayerPiece())==d
                    && board1[current.getRow()-2][current.getColumn()-2].isEmpty()){

                board1[current.getRow()-2][current.getColumn()-2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
            if(current.getRow()-2>=0
                    && current.getColumn()+2<column
                    && Character.toLowerCase(board1[current.getRow()-1][current.getColumn()+1].getPlayerPiece())==d
                    && board1[current.getRow()-2][current.getColumn()+2].isEmpty()){

                board1[current.getRow()-2][current.getColumn()+2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
        }
        //if the piece is white and not a king
        if(c=='w' && board1[current.getRow()][current.getColumn()].isKing()==false
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()+2<row
                    && current.getColumn()+2<column
                    && Character.toLowerCase(board1[current.getRow()+1][current.getColumn()+1].getPlayerPiece())==d
                    && board1[current.getRow()+2][current.getColumn()+2].isEmpty()){

                board1[current.getRow()+2][current.getColumn()+2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
            if(current.getRow()+2<row
                    && current.getColumn()-2>=0
                    && Character.toLowerCase(board1[current.getRow()+1][current.getColumn()-1].getPlayerPiece())==d
                    && board1[current.getRow()+2][current.getColumn()-2].isEmpty()){

                board1[current.getRow()+2][current.getColumn()-2].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
                numberJumps++;
            }
        }

        return numberJumps;
    }

    protected void noJumpsMove(row_column current){ //this is called on all pieces if there are no possible jumps

        char d;
        char c = convertPlayerTurnToPieceLetter(current);
        d=' ';

        if(board1[current.getRow()][current.getColumn()].isKing()
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()+1<row
                    && current.getColumn()+1<column
                    && board1[current.getRow()+1][current.getColumn()+1].getPlayerPiece()==d){
                board1[current.getRow()+1][current.getColumn()+1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
            if(current.getRow()-1>=0
                    && current.getColumn()+1<column
                    &&board1[current.getRow()-1][current.getColumn()+1].getPlayerPiece()==d){
                board1[current.getRow()-1][current.getColumn()+1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
            if(current.getRow()+1<column
                    &&current.getColumn()-1>=0
                    &&board1[current.getRow()+1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()+1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
            if(current.getRow()-1>=0
                    &&current.getColumn()-1>=0
                    &&board1[current.getRow()-1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()-1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
        }
        if(c=='r' && board1[current.getRow()][current.getColumn()].isKing()==false
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()+1<row
                    &&current.getColumn()-1>=0
                    &&board1[current.getRow()+1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()+1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
            if(current.getRow()-1>=0
                    && current.getColumn()-1>=0
                    &&board1[current.getRow()-1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()-1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
        }
        if(c=='w' && board1[current.getRow()][current.getColumn()].isKing()==false
                &&board1[current.getRow()][current.getColumn()].getPlayerPiece()==c){
            if(current.getRow()+1<row
                    &&current.getColumn()-1>=0
                    &&board1[current.getRow()+1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()+1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
            if(current.getRow()-1>=0
                    &&current.getColumn()-1>=0
                    &&board1[current.getRow()-1][current.getColumn()-1].getPlayerPiece()==d){
                board1[current.getRow()-1][current.getColumn()-1].setPlayerPiece('p');
                board1[current.getRow()][current.getColumn()].setPlayerPiece('P');
            }
        }


    }

    public void resetBoard(row_column currentPlayer){

        char c = convertPlayerTurnToPieceLetter(currentPlayer);
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                if(board1[i][j].getPlayerPiece()=='P' &&board1[i][j].isKing()==false ){
                    board1[i][j].setPlayerPiece(c);
                }else if(board1[i][j].getPlayerPiece()=='P' &&board1[i][j].isKing()){
                    board1[i][j].setPlayerPiece(Character.toUpperCase(c));
                }else if(board1[i][j].getPlayerPiece()=='p'){
                    board1[i][j].setPlayerPiece(' ');
                }
            }
        }
    }

    protected void movePiece(row_column original, row_column change ){//checks if it is a legal move then will remove pieces
        char c;
        c = convertPlayerTurnToPieceLetter(original);
        //from my research, the forced jump rule does not prevent you from choosing a piece with a single jump
        //even if a multijump is available
        //but you must finish the multijump if you start it

        errorCheckingMovePiece(original, change);
        //actually moving the piece
        board1[original.getRow()][original.getColumn()].setPlayerPiece(' ');
        board1[change.getRow()][change.getColumn()].setPlayerPiece(c);
        removingJumpedPiece(original, change);
        makeKing(change);

    }

    private void makeKing(row_column change) {
        if(change.getRow()==0 &&board1[change.getRow()][change.getColumn()].getPlayerPiece()== 'r'){
            board1[change.getRow()][change.getColumn()].setKing();
        }else if(change.getRow()==7 && board1[change.getRow()][change.getColumn()].getPlayerPiece()== 'w'){
            board1[change.getRow()][change.getColumn()].setKing();
        }
    }

    private char convertPlayerTurnToPieceLetter(row_column original) {
        char c;
        if(original.getPlayerTurn()==0 && board1[original.getRow()][original.getColumn()].isKing()==false){
            c='r';
        }else if(original.getPlayerTurn()==1 && board1[original.getRow()][original.getColumn()].isKing()==false){
            c='w';
        }else if(original.getPlayerTurn()==0 && board1[original.getRow()][original.getColumn()].isKing()){
            c='R';
        }else{
            c='W';
        }
        return c;
    }

    private void errorCheckingMovePiece(row_column original, row_column change) {
        if(original.getColumn()-change.getColumn()>2 ||original.getColumn()-change.getColumn()<-2){
            throw new IllegalArgumentException("Those coordinates dont work together");
        }else if(original.getRow()-change.getRow()>2 ||original.getRow()-change.getRow()<-2 ){
            throw new IllegalArgumentException("Those coordinates dont work together");
        }else if(original.getRow()<0 || original.getRow()>=row){
            throw new IllegalArgumentException("Original coordinate is out of bounds");
        }else if(original.getColumn()<0 || original.getColumn()>=column){
            throw new IllegalArgumentException("Original coordinate is out of bounds");
        }else if(change.getRow()<0 || change.getRow()>=row){
            throw new IllegalArgumentException("new coordinate is out of bounds");
        }else if(change.getColumn()<0 || change.getColumn()>=column){
            throw new IllegalArgumentException("new coordinate is out of bounds");
        }else if(board1[original.getRow()][original.getColumn()].getPlayerPiece()!='P'){
            throw new IllegalArgumentException("You cant move that piece");
        }else if(board1[change.getRow()][change.getColumn()].getPlayerPiece()!='p'){
            throw new IllegalArgumentException("You cant move a piece to that square ");
        }
    }

    private void removingJumpedPiece(row_column original, row_column change) {
        //does nothing if there was no jump
        if(original.getColumn()-change.getColumn()==2){
            if(original.getRow()-change.getRow()==2){
                board1[original.getRow()-1][original.getColumn()-1].setPlayerPiece(' ');
            }else if(original.getRow()-change.getRow()==-2){
                board1[original.getRow()+1][original.getColumn()-1].setPlayerPiece(' ');
            }
        }else if(original.getColumn()-change.getColumn()==-2){
            if(original.getRow()-change.getRow()==2){
                board1[original.getRow()-1][original.getColumn()+1].setPlayerPiece(' ');
            }else if(original.getRow()-change.getRow()==-2){
                board1[original.getRow()+1][original.getColumn()+1].setPlayerPiece(' ');
            }
        }
    }

    @Override
    protected boolean isWinner(int playerTurn, int row, int column) {
        char c;
        if(playerTurn==0){
            c='r';
        }else{
            c='w';
        }

        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                if(c==Character.toLowerCase(board1[i][j].getPlayerPiece())){
                    return false;
                }
            }
        }
        return true;
    }

}
