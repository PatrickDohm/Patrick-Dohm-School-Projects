import java.util.Scanner;

public class PlayCheckers extends Play {
checkers_board board1;
int row=8;
int column=8;
    Scanner sc;
    public PlayCheckers(){
        board1=new checkers_board();
        board1.printBoard();
        sc=new Scanner(System.in);
    }

    public void StartCheckers() {
        row_column original= new row_column();
        row_column change= new row_column();

        while(board1.isWinner(playerTurn,0,0)){
            original.setPlayerTurn(playerTurn);
            change.setPlayerTurn(playerTurn);

            char c;
            if(original.getPlayerTurn()==0){
                c='r';
            }else{
                c='w';
            }
            //checking jumps
            int possiblejumps=0;
            for(int i=0;i<row;i++){
                for(int j=0;j<column;j++){
                    original.setColumn(j);
                    original.setRow(i);
                    possiblejumps+=board1.possibleMove(original);
                }
            }
            //no jumps case
            if(possiblejumps==0){
                for(int i=0;i<row;i++){
                    for(int j=0;j<column;j++){
                        original.setColumn(j);
                        original.setRow(i);
                        board1.noJumpsMove(original);
                    }
                }
            }

            String input;
            try{
                do{
                    board1.printBoard();
                    System.out.println("Player "+playerTurn+" take your turn");
                    input=sc.nextLine();
                    //input should look like A4-B5
                    original.setColumn(board1.convertColumnToNumber(input.charAt(0)));
                    original.setRow(Character.getNumericValue(input.charAt(1)));
                    original.setRow(original.getRow()-1);
                    change.setColumn(board1.convertColumnToNumber(input.charAt(3)));
                    change.setRow(Character.getNumericValue(input.charAt(4)));
                    change.setRow(change.getRow()-1);
                    board1.movePiece(original,change);
                    board1.resetBoard(change);
                    board1.printBoard();
                    if(possiblejumps!=0){
                        possiblejumps=board1.possibleMove(change);
                    }


                }while(possiblejumps!=0);



        }catch(IllegalStateException e){
            System.out.println("Columns are from a to h");
            }catch (IllegalArgumentException e){
                System.out.println(e);
            }


            changePlayerTurn();


    }


    }




}
