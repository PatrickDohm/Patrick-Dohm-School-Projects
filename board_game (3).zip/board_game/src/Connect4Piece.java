public class Connect4Piece extends Piece {
    public Connect4Piece(){
        super.playerPiece='*';
    }
}
