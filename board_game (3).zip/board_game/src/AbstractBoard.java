public abstract class AbstractBoard {
    int row;
    int column;


    Piece[][] board;

    protected abstract int placePiece(int playerTurn, int row, int column);
    protected int convertColumnToNumber(char column){
        switch (Character.toLowerCase(column)) {
            case 'a':
                return 0;
            case 'b':
                return 1;
            case 'c':
                return 2;
            case 'd':
                return 3;
            case 'e':
                return 4;
            case 'f':
                return 5;
            case 'g':
                return 6;
            case 'h':
                return 7;
            default:
                throw new IllegalArgumentException();
        }
    }
    protected int ConvertRow(int row){
        switch(row){
            case 8: return 0;
            case 7: return 1;
            case 6: return 2;
            case 5: return 3;
            case 4: return 4;
            case 3: return 5;
            case 2: return 6;
            case 1: return 7;
            default:
                throw new IllegalArgumentException("cant convert row");

        }
    }



    protected void printBoard(){

        System.out.println("\n");//make sure the next board has space

        char columnHeader='A';
        int rowHeader=8;
        for(int j=0;j<row;j++){
            for(int i=0;i<column;i++){
                System.out.print("----------");
            }
            System.out.print("\n");
            System.out.print(rowHeader);
            rowHeader--;
            for(int i=0;i<column;i++){
                System.out.print(String.format("%-5s%-5c", "|", this.board[j][i].getPlayerPiece()));
            }
            System.out.print("|\n");

        }


        for(int i=0;i<row;i++){
            System.out.print("----------");
        }
        System.out.print("\n");
        System.out.print(" ");
        for(int i=0;i<column;i++){
            System.out.print(String.format("%-5s%-5c", "|", columnHeader));
            columnHeader++;
        }
        System.out.println("|\n");


    }

    protected Piece getSquare(int row, char column){
        return board[row][convertColumnToNumber(column)];
    }

    protected int possibleMove(row_column current){
    return 0;
    }

    protected abstract boolean isWinner(int playerTurn, int row, int column);
    protected boolean winnerMessage(char player){
        int players=0;
        if(player=='a'){
            players=1;
        }else{
            players=2;
        }

        System.out.println("Player "+players+" has won the game");
        return true;
    }

}
