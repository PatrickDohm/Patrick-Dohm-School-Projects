import java.util.Scanner;

public class PlayGomoku extends Play {

    Gomoku_Board board;

    Scanner sc;
    public void StartGomuku() {
        GomokuInit();
        board.printBoard();
        System.out.println("Welcome to Connect 4");
        PlayGame();
    }

    private void PlayGame() {
        int row=0;
        int column=0;
        do{
            changePlayerTurn();
            board.printBoard();
            printPlayerTurn();
            System.out.println("Type the number of the row and the Letter of the column you want to place your piece in");
            String[] input = new String[2];
            try{
                input=sc.nextLine().split(" ");
                column = board.convertColumnToNumber(input[1].charAt(0));
                row=Integer.parseInt(input[0]);
                row=row-1;
                board.placePiece(playerTurn, row,column);
            }catch(IllegalStateException e){
                changePlayerTurn();
                System.out.println("Column needs to be between a and s");
            }catch (IllegalArgumentException e){
                System.out.println("That space is taken");
                changePlayerTurn();
            }

        }while(board.isWinner(playerTurn, row, column)==false);
    }

    private void GomokuInit() {
        board=new Gomoku_Board();
        playerTurn=1;
        sc= new Scanner(System.in);
    }
}
