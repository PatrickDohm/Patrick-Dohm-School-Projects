public class Gomoku_Board extends AbstractBoard{
    public Gomoku_Board(){
        super.row=19;
        super.column=19;
        board= new GomokuPiece[row][column];
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                board[i][j]=new GomokuPiece();
            }
    }
    }
    @Override
    protected void printBoard(){    //I only need to override because the columns werent lining up

        System.out.println("\n");//make sure the next board has space

        char columnHeader='A';
        int rowHeader=1;
        for(int j=0;j<row;j++){
            for(int i=0;i<column;i++){
                System.out.print("-----------");
            }
            System.out.print("\n");
            if(rowHeader<10){
                System.out.print(rowHeader+ " ");
            }else{
            System.out.print(rowHeader);
            }
            rowHeader++;
            for(int i=0;i<column;i++){
                System.out.print(String.format("%-5s%-5c|", "|", this.board[j][i].getPlayerPiece()));
            }
            System.out.print("\n");

        }

        for(int i=0;i<row;i++){
            System.out.print("-----------");
        }
        System.out.print("\n");
        System.out.print("  ");
        for(int i=0;i<column;i++){
            System.out.print(String.format("%-5s%-5c|", "|", columnHeader));
            columnHeader++;
        }


    }

    @Override
    protected int placePiece(int playerTurn, int row, int column) {
        char player=' ';
        if(playerTurn==0){
            player='a';
        }else if(playerTurn==1){
            player='b';
        }
        if(board[row][column].isEmpty()){
            board[row][column].setPlayerPiece(player);
            return row;
        }else{
            throw new IllegalArgumentException();
        }
    }

    @Override
    protected int convertColumnToNumber(char column) {

        switch (Character.toLowerCase(column)){
            case 'a': return 0;
            case 'b': return 1;
            case 'c': return 2;
            case 'd': return 3;
            case 'e': return 4;
            case 'f': return 5;
            case 'g': return 6;
            case 'h': return 7;
            case 'i': return 8;
            case 'j': return 9;
            case 'k': return 10;
            case 'l': return 11;
            case 'm': return 12;
            case 'n': return 13;
            case 'o': return 14;
            case 'p': return 15;
            case 'q': return 16;
            case 'r': return 17;
            case 's': return 18;
            default:throw new IllegalStateException();
        }
    }



    @Override
    protected boolean isWinner(int playerTurn, int row, int column) {
        char player=' ';
        if(playerTurn==0){
            player='a';
        }else if(playerTurn==1){
            player='b';
        }

        //test piece placed on edge
        if(fourAbove( row, column, player)) return winnerMessage(player);
        if(fourBelow( row, column, player)) return winnerMessage(player);
        if(fourLeft(row, column, player)) return winnerMessage(player);
        if(fourRight(row, column, player)) return winnerMessage(player);
        if(fourUpRight(row, column, player)) return winnerMessage(player);
        if(fourDownRight(row, column, player)) return winnerMessage(player);
        if(fourUpLeft(row, column, player)) return winnerMessage(player);
        if(fourDownLeft(row, column, player)) return winnerMessage(player);

        //test piece placed in middle
        if(middleHorizontal(row, column, player)) return winnerMessage(player);
        if(middleVertical(row, column, player)) return winnerMessage(player);
        if(middleDiagonal(row, column, player)) return winnerMessage(player);
        if(middleDiagonalReverse(row, column, player)) return winnerMessage(player);

        //test piece placed inbetween middle and edge
        if(threeUpOneDown(row, column, player)) return winnerMessage(player);
        if(threeRightOneLeft(row, column, player)) return winnerMessage(player);
        if(threeUpRightOneDownLeft(row, column, player)) return winnerMessage(player);
        if(threeUpLeftOneDownRight(row, column, player)) return winnerMessage(player);




        return false;
    }

    private boolean threeUpLeftOneDownRight(int row, int column, char player) {
        if(row-3>=0 && column-3>=0 && board[row-3][column-3].playerPiece==player){
            if(row+1<19 && column+1<19 && board[row+1][column+1].playerPiece==player){
                if(board[row-2][column-2].playerPiece==player){
                    if(board[row-1][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        if(row+3<19 && column+3<19 && board[row+3][column+3].playerPiece==player){
            if(row-1>=0 && column-1>=0 && board[row-1][column-1].playerPiece==player){
                if(board[row+2][column+2].playerPiece==player){
                    if(board[row+1][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }


        return false;
    }

    private boolean threeUpRightOneDownLeft(int row, int column, char player) {
        if(row-3>=0 && column+3<19 && board[row-3][column+3].playerPiece==player){
            if(row+1<19 && column-1>=0 && board[row+1][column-1].playerPiece==player){
                if(board[row-2][column+2].playerPiece==player){
                    if(board[row-1][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        if(row+3<19 && column-3>=0 && board[row+3][column-3].playerPiece==player){
            if(row-1>=0 && column+1<19 && board[row-1][column+1].playerPiece==player){
                if(board[row+2][column-2].playerPiece==player){
                    if(board[row+1][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private boolean threeRightOneLeft(int row, int column, char player) {
        //xcxxx
        if(column+3<19 && board[row][column+3].playerPiece==player){
            if(column-1>=0 && board[row][column-1].playerPiece==player){
                if(board[row][column+2].playerPiece==player){
                    if(board[row][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        if(column-3>=0 && board[row][column-3].playerPiece==player){
            if(column+1<19 && board[row][column+1].playerPiece==player){
                if(board[row][column-2].playerPiece==player){
                    if(board[row][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private boolean threeUpOneDown(int row, int column, char player) {
        //x
        //x
        //x
        //c
        //x
        if(row-3>=0 && board[row-3][column].playerPiece==player){
            if(row+1<19 && board[row+1][column].playerPiece==player){
                if(board[row-2][column].playerPiece==player){
                    if(board[row-1][column].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        if(row+3<19 && board[row+3][column].playerPiece==player){
            if(row-1>=0 && board[row-1][column].playerPiece==player){
                if(board[row+2][column].playerPiece==player){
                    if(board[row+1][column].playerPiece==player){
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private boolean middleDiagonalReverse(int row, int column, char player) {
        //x
        // x
        //  c
        //   x
        //    x
        if(row+2<19 && row-2>=0 && column+2<19 && column-2>=0
                && board[row-2][column+2].playerPiece==player
                && board[row+2][column-2].playerPiece==player){
            if(board[row-1][column+1].playerPiece==player && board[row+1][column+1].playerPiece==player){
                return true;
            }
        }
        return false;
    }

    private boolean middleDiagonal(int row, int column, char player) {
        //     x
        //    x
        //   c
        //  x
        // x
        if(row+2<19 && row-2>=0 && column+2<19 && column-2>=0 
                && board[row+2][column+2].playerPiece==player
                && board[row-2][column-2].playerPiece==player){
            if(board[row+1][column+1].playerPiece==player && board[row-1][column+1].playerPiece==player){
                return true;
            }
        }
        return false;
    }

    private boolean middleVertical(int row, int column, char player) {
        if(row+2<19 && row-2>=0 && board[row+2][column].playerPiece==player && board[row-2][column].playerPiece==player){
            if(board[row+1][column].playerPiece==player && board[row-1][column].playerPiece==player){
                return true;
            }
        }
        return false;
    }

    private boolean middleHorizontal(int row, int column, char player) {
        if(column+2<19 && column-2>=0 && board[row][column+2].playerPiece==player && board[row][column-2].playerPiece==player){
            if(board[row][column+1].playerPiece==player && board[row][column-1].playerPiece==player){
                return true;
            }
        }
        return false;
    }

    private boolean fourDownLeft(int row, int column, char player) {
        if(column-4>=0 && row+4<19 && board[row+4][column-4].playerPiece==player){
            if(board[row+3][column-3].playerPiece==player){
                if(board[row+2][column-2].playerPiece==player){
                    if(board[row+1][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean fourUpLeft(int row, int column, char player) {
        if(column-4>=0 && row-4>=0 && board[row-4][column-4].playerPiece==player){
            if(board[row-3][column-3].playerPiece==player){
                if(board[row-2][column-2].playerPiece==player){
                    if(board[row-1][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean fourDownRight(int row, int column, char player) {
        if(column+4<19 && row+4<19 && board[row+4][column+4].playerPiece==player){
            if(board[row+3][column+3].playerPiece==player){
                if(board[row+2][column+2].playerPiece==player){
                    if(board[row+1][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean fourUpRight(int row, int column, char player) {
        if(column+4<19 && row-4>=0 && board[row-4][column+4].playerPiece==player){
            if(board[row-3][column+3].playerPiece==player){
                if(board[row-2][column+2].playerPiece==player){
                    if(board[row-1][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private boolean fourRight(int row, int column, char player) {
        if(column+4<19 && board[row][column+4].playerPiece==player){
            if(board[row][column+3].playerPiece==player){
                if(board[row][column+2].playerPiece==player){
                    if(board[row][column+1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private boolean fourLeft(int row, int column, char player) {
        if(column-4>=0 && board[row][column-4].playerPiece==player){
            if(board[row][column-3].playerPiece==player){
                if(board[row][column-2].playerPiece==player){
                    if(board[row][column-1].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean fourBelow(int row, int column, char player) {
        if(row+4<19 && board[row+4][column].playerPiece==player){
            if(board[row+3][column].playerPiece==player){
                if(board[row+2][column].playerPiece==player){
                    if(board[row+1][column].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean fourAbove(int row, int column, char player) {
        if(row-4>=0 && board[row-4][column].playerPiece==player){
            if(board[row-3][column].playerPiece==player){
                if(board[row-2][column].playerPiece==player){
                    if(board[row-1][column].playerPiece==player){
                        return true;
                    }
                }
            }
        }
        return false;
    }

}

