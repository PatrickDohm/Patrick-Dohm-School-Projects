public class ChessPieceControl {
    ChessBoard board1;
    public ChessPieceControl(ChessBoard board){
        board1=board;
    }

    //the moves each piece can do at any time
    public void PawnMoves(row_column current){
        //pawn promotion is not determined here, this only lists possible moves
        if(current.getPlayerTurn()==1){
            //move forward 2 spaces on first move
            if(board1.dummyboard[current.getRow()][current.getColumn()].numberMoves==0
            && board1.dummyboard[current.getRow()+1][current.getColumn()].getPlayerPiece()==' '
            && board1.dummyboard[current.getRow()+2][current.getColumn()].getPlayerPiece()==' '){
                board1.dummyboard[current.getRow()+2][current.getColumn()].setPlayerPiece('*');
            }
            //taking a piece
            if(current.getColumn()+1<=7
                    &&current.getRow()+1<=7
                    &&Character.isUpperCase(board1.dummyboard[current.getRow()+1][current.getColumn()+1].getPlayerPiece())){
                board1.dummyboard[current.getRow()+1][current.getColumn()+1].setPlayerPiece('*');
            }else if(current.getRow()+1<=7&&
                    current.getColumn()-1>=0
                    &&Character.isUpperCase(board1.dummyboard[current.getRow()+1][current.getColumn()-1].getPlayerPiece())){
                board1.dummyboard[current.getRow()+1][current.getColumn()-1].setPlayerPiece('*');
            }

            //move forward 1 space
            if(current.getRow()+1<8){
                if(board1.dummyboard[current.getRow()+1][current.getColumn()].getPlayerPiece()==' '){
                    board1.dummyboard[current.getRow()+1][current.getColumn()].setPlayerPiece('*');
                }
            }

        }else if(current.getPlayerTurn()==2){
            //move forward 2
            if(board1.dummyboard[current.getRow()][current.getColumn()].numberMoves==0
                    && board1.dummyboard[current.getRow()-1][current.getColumn()].getPlayerPiece()==' '
                    && board1.dummyboard[current.getRow()-2][current.getColumn()].getPlayerPiece()==' '){
                board1.dummyboard[current.getRow()-2][current.getColumn()].setPlayerPiece('*');
            }
            //take a piece
            if(current.getColumn()+1<=7
                    &&current.getRow()-1>=0
                    &&Character.isLowerCase(board1.dummyboard[current.getRow()-1][current.getColumn()+1].getPlayerPiece())){
                board1.dummyboard[current.getRow()-1][current.getColumn()+1].setPlayerPiece('*');
            }else if(current.getRow()-1>=0
                    &&current.getColumn()-1>=0
                    &&Character.isLowerCase(board1.dummyboard[current.getRow()-1][current.getColumn()-1].getPlayerPiece())){
                board1.dummyboard[current.getRow()-1][current.getColumn()-1].setPlayerPiece('*');
            }

            //move forward 1
            if(current.getRow()-1>=0){
                if(board1.dummyboard[current.getRow()-1][current.getColumn()].getPlayerPiece()==' '){
                    board1.dummyboard[current.getRow()-1][current.getColumn()].setPlayerPiece('*');
                }
            }

        }
    }

    public void RookMoves(row_column current){
        row_column move= new row_column();
        //move in straight line until there is a piece in the way
        //if the piece is the opposite player then you can take it


            //move up
            move.setRow(current.getRow()-1);
            move.setColumn(current.getColumn());
            move.setPlayerTurn(current.getPlayerTurn());
            RookHelperFunction(move,-1,0);

            //move down
            move.setRow(current.getRow()+1);
            move.setColumn(current.getColumn());
            RookHelperFunction(move,1,0);


            //move left
            move.setRow(current.getRow());
            move.setColumn(current.getColumn()-1);
            RookHelperFunction(move,0,-1);

            //move Right
            move.setRow(current.getRow());
            move.setColumn(current.getColumn()+1);
            RookHelperFunction(move,0,1);


    }
    private void RookHelperFunction(row_column move, int rowAdjust, int columnAdjust){
        while(move.getColumn()<=7 && move.getColumn()>=0
                && move.getRow()>=0
                &&move.getRow()<=7
                && board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece()==' '){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            move.setColumn(move.getColumn()+columnAdjust);
            move.setRow(move.getRow()+rowAdjust);
        }
        if(move.getRow()>=0 && move.getRow()<=7
                &&move.getColumn()>=0 && move.getColumn()<=7
                &&move.getPlayerTurn()==1
                && Character.isUpperCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }else if(move.getPlayerTurn()==2
                && move.getColumn()>=0 && move.getColumn()<=7
                && move.getRow()>=0 && move.getRow()<=7
                && Character.isLowerCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }else if (move.getRow()>=0 && move.getRow()<=7
                &&move.getColumn()>=0 && move.getColumn()<=7){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }
    }

    public void BishopMoves(row_column current){
        //the bishop can only move in diagonals
        //it can keep moving until there is a piece in its way
        //if that piece is the opposite player you can take it
        row_column move= new row_column();
        move.setPlayerTurn(current.getPlayerTurn());
            //move upLeft
            move.setRow(current.getRow()-1);
            move.setColumn(current.getColumn()-1);
            BishopHelperFunctionP1(move,-1,-1);

            //move upRight
            move.setRow(current.getRow()-1);
            move.setColumn(current.getColumn()+1);
            BishopHelperFunctionP1(move,1,-1);

            //move downLeft
            move.setRow(current.getRow()+1);
            move.setColumn(current.getColumn()-1);
            BishopHelperFunctionP1(move,-1,1);

            //move downRight
            move.setRow(current.getRow()+1);
            move.setColumn(current.getColumn()+1);
            BishopHelperFunctionP1(move,1,1);


    }

    private void BishopHelperFunctionP1(row_column move, int adjustColumn, int adjustRow) {
        while(move.getColumn()>0 && move.getRow()>0 && move.getColumn()<7 && move.getRow()<7
                && board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece()==' '){

            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            move.setColumn(move.getColumn()+adjustColumn);
            move.setRow(move.getRow()+adjustRow);
        }
        if(move.getColumn()>=0 && move.getRow()>=0 && move.getColumn()<=7 && move.getRow()<=7
        &&move.getPlayerTurn()==1 &&Character.isUpperCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }else if(move.getColumn()>=0 && move.getRow()>=0 && move.getColumn()<=7 && move.getRow()<=7
                &&move.getPlayerTurn()==2 &&Character.isLowerCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }else if(move.getColumn()>=0 && move.getRow()>=0 && move.getColumn()<=7 && move.getRow()<=7){
            board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
        }
    }

    public void KnightMoves(row_column current){
        //The knight can move in an L shape.
        //The only thing restricting where the Knight can move are the board size and ally pieces
        //n=knight, *=move
        row_column move= new row_column();
        //*bb
        //  n
        move.setRow(current.getRow()-1);
        move.setColumn(current.getColumn()-2);
        KnightHelperFunction(current, move);

        //*b
        // b
        // n
        move.setRow(current.getRow()-2);
        move.setColumn(current.getColumn()-1);
        KnightHelperFunction(current, move);

        //b*
        //b
        //n
        move.setRow(current.getRow()-2);
        move.setColumn(current.getColumn()+1);
        KnightHelperFunction(current,move);

        //bb*
        //n
        move.setRow(current.getRow()-1);
        move.setColumn(current.getColumn()+2);
        KnightHelperFunction(current,move);

        //n
        //bb*
        move.setRow(current.getRow()+1);
        move.setColumn(current.getColumn()+2);
        KnightHelperFunction(current,move);

        //n
        //b
        //b*
        move.setRow(current.getRow()+2);
        move.setColumn(current.getColumn()+1);
        KnightHelperFunction(current,move);

        // n
        // b
        //*b
        move.setRow(current.getRow()+2);
        move.setColumn(current.getColumn()-1);
        KnightHelperFunction(current,move);

        //bbn
        //*
        move.setRow(current.getRow()+1);
        move.setColumn(current.getColumn()-2);
        KnightHelperFunction(current,move);

    }

    private void KnightHelperFunction(row_column current, row_column move) {
        if (move.getRow() >= 0 && move.getColumn() >= 0 && move.getRow()<=7 && move.getColumn()<=7) {
            if (board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece() == ' ') {
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            } else if (current.getPlayerTurn() == 1 &&
                    Character.isUpperCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())) {
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            } else if (current.getPlayerTurn() == 2
                    && Character.isLowerCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())) {
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            }
        }
    }

    public void QueenMove(row_column current){
        //The Queen is essentially a combination of the rook and bishop
        RookMoves(current);
        BishopMoves(current);
    }

    public void KingMove(row_column current){
        //The king can move in any direction one space, castling will be handled here
        row_column move= new row_column();
        //moveUp
        move.setPlayerTurn(current.getPlayerTurn());
        move.setRow(current.getRow()-1);
        move.setColumn(current.getColumn());
        KingHelperFunction(move);

        //move upLeft
        move.setColumn(current.getColumn()-1);
        move.setRow(current.getRow()-1);
        KingHelperFunction(move);

        //moveLeft
        move.setColumn(current.getColumn()-1);
        move.setRow(current.getRow());
        KingHelperFunction(move);

        //moveDownLeft
        move.setRow(current.getRow()+1);
        move.setColumn(current.getColumn()-1);
        KingHelperFunction(move);

        //moveDown
        move.setRow(current.getRow()+1);
        move.setColumn(current.getColumn());
        KingHelperFunction(move);

        //moveDownRight
        move.setRow(current.getRow()+1);
        move.setColumn(current.getColumn()+1);
        KingHelperFunction(move);

        //moveRight
        move.setRow(current.getRow());
        move.setColumn(current.getColumn()+1);
        KingHelperFunction(move);

        //moveUpRight
        move.setRow(current.getRow()-1);
        move.setColumn(current.getColumn()+1);
        KingHelperFunction(move);

        canCastle(current);
    }

    private void KingHelperFunction(row_column move) {
        if(move.getRow()>=0 && move.getRow()<=7 && move.getRow()>=0 && move.getRow()<=7){
            if(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece()==' '){
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            }else if(move.getPlayerTurn()==1 && Character.isUpperCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            }else if(move.getPlayerTurn()==2 && Character.isLowerCase(board1.dummyboard[move.getRow()][move.getColumn()].getPlayerPiece())){
                board1.dummyboard[move.getRow()][move.getColumn()].setPlayerPiece('*');
            }
        }
    }
    private void canCastle(row_column current) {
        //Castle Rules
        //1)King and Rook can't have moved
        //2)all spaces in between them must be empty

        if (board1.dummyboard[current.getRow()][current.getColumn()].numberMoves == 0) {
            if (current.getPlayerTurn() == 1) {
                if (board1.dummyboard[0][0].getPlayerPiece() == 'r'
                        && board1.dummyboard[0][0].numberMoves == 0) {
                    if (board1.dummyboard[0][1].getPlayerPiece() == ' '
                            && board1.dummyboard[0][2].getPlayerPiece() == ' '
                            && board1.dummyboard[0][3].getPlayerPiece() == ' ') {
                        board1.dummyboard[0][2].setPlayerPiece('*');
                    }
                } else if (board1.dummyboard[0][7].getPlayerPiece() == 'r'
                        && board1.dummyboard[0][7].numberMoves == 0) {
                    if (board1.dummyboard[0][6].getPlayerPiece() == ' '
                            && board1.dummyboard[0][5].getPlayerPiece() == ' ') {
                        board1.dummyboard[0][6].setPlayerPiece('*');
                    }
                }
            } else if (current.getPlayerTurn() == 2) {
                if (board1.dummyboard[7][0].getPlayerPiece() == 'R'
                        && board1.dummyboard[7][0].numberMoves == 0) {
                    if (board1.dummyboard[7][1].getPlayerPiece() == ' '
                            && board1.dummyboard[7][2].getPlayerPiece() == ' '
                            && board1.dummyboard[7][3].getPlayerPiece() == ' ') {
                        board1.dummyboard[7][2].setPlayerPiece('*');
                    }
                } else if (board1.dummyboard[7][7].getPlayerPiece() == 'R'
                        && board1.dummyboard[7][7].numberMoves == 0) {
                    if (board1.dummyboard[7][6].getPlayerPiece() == ' '
                            && board1.dummyboard[7][5].getPlayerPiece() == ' ') {
                        board1.dummyboard[7][6].setPlayerPiece('*');
                    }
                }
            }
        }

    }
}
