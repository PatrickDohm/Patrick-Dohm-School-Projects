public class row_column {
   int row;
   int column;
   int playerTurn;
    public row_column(int row, int column, int playerTurn){
        row=this.row;
        column=this.column;
        playerTurn=this.playerTurn;
    }
    public row_column(){
        row=0;
        column=0;
        playerTurn=0;
    }


    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getPlayerTurn() {
        return playerTurn;
    }

    public void setPlayerTurn(int playerTurn) {
        this.playerTurn = playerTurn;
    }
}
