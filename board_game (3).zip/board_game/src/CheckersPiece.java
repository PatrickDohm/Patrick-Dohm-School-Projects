public class CheckersPiece extends Piece{
    private boolean black; //pieces can only exist on black squares.
    private boolean isKing;

    public CheckersPiece(){

        black=false;
        isKing=false;
    }

    public void setBlack(){
        black=true;
    }
    public boolean getBlack(){
        return black;
    }

    public void setKing() {
        isKing = true;
    }
    public boolean isKing() {
        return isKing;
    }

}
