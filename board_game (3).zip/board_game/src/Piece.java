public class Piece {
    char playerPiece;

    public Piece(){
        this.setPlayerPiece(' ');
    }
    protected boolean isEmpty(){
        if(this.playerPiece==' '){
            return true;
        }
        return false;
    }
    protected void setPlayerPiece(char a){
        this.playerPiece=a;
    }
    protected char getPlayerPiece(){
        return playerPiece;
    }

}
