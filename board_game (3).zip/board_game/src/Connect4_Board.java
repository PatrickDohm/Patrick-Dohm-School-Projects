public class Connect4_Board extends AbstractBoard {

    public Connect4_Board(){
        //board is fixed size
        super.row=6;
        super.column=7;
        board= new Connect4Piece[row][column];
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                board[i][j]=new Connect4Piece();
            }
        }
    }
    @Override
    protected int placePiece(int playerTurn,int row, int column){//always set row to 0


        char player=' ';


        if(playerTurn==0){
             player='a';
        }else if(playerTurn==1){
            player='b';
        }else{
            throw new IllegalArgumentException("Player turn needs to be 0 or 1");
        }

        //if the top row is empty then the player can place a piece in that column
        if(this.board[0][column].isEmpty()){
            if((row+1)<6 && this.board[row+1][column].isEmpty()==true){
                return placePiece(playerTurn, row+1,column);
            }else{
                this.board[row][column].setPlayerPiece(player);
                return row;
            }
        }else{
            throw new IllegalStateException();
        }


    }

    @Override
    protected int convertColumnToNumber(char column) {
            switch (Character.toLowerCase(column)) {
                case 'a':
                    return 0;
                case 'b':
                    return 1;
                case 'c':
                    return 2;
                case 'd':
                    return 3;
                case 'e':
                    return 4;
                case 'f':
                    return 5;
                case 'g':
                    return 6;
                default:
                    throw new IllegalArgumentException();
            }



    }

    @Override
    protected boolean isWinner(int playerTurn, int row, int column) {//always initially pass 0

        char player=' ';
        if(playerTurn==0){
            player='a';
        }else if(playerTurn=='b'){
            player='b';
        }

        //test when the piece placed is an end piece
        if (threeBelow(row, column, player)) return winnerMessage(player);
        if (threeAbove(row, column, player)) return winnerMessage(player);
        if(threeToLeft(player, row, column)){ return winnerMessage(player);}
        if(threeToRight(player,row,column)) return winnerMessage(player);
        if(threeToUpRight(player,row,column)) return winnerMessage(player);
        if(threeToUpLeft(player,row,column)) return winnerMessage(player);
        if(threeToDownRight(player,row,column)) return winnerMessage(player);
        if(threeToDownLeft(player,row,column)) return winnerMessage(player);

        //test when piece placed is in the middle
        if(twoUpOneDown(player,row,column)) return winnerMessage(player);
        if(twoLeftOneRight(player,row,column)) return winnerMessage(player);
        if(middleDiagonal(player,row,column)) return winnerMessage(player);
        if(middleDiagonalReverse(player,row,column)) return winnerMessage(player);


        return false;
    }


    private boolean threeBelow(int row, int column, char player) {
        if(row+1<6 && board[row+1][column].playerPiece==player){
            if(row+2<6 && board[row+2][column].playerPiece==player){
                if(row+3<6 && board[row+3][column].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeAbove(int row, int column, char player) {
        if(row-1>=0 && board[row-1][column].playerPiece==player){
            if(row-2>=0 && board[row-2][column].playerPiece==player){
                if(row-3>=0 && board[row-3][column].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToLeft(char player, int row, int column){//test if there are 3 pieces to the left
        if(column-1>=0 && board[row][column-1].playerPiece==player){
            if(column-2>=0 && board[row][column-2].playerPiece==player){
                if(column-3>=0 && board[row][column-3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToRight(char player, int row, int column){//test if there are 3 pieces to the left
        if(column+1<=6 && board[row][column+1].playerPiece==player){
            if(column+2<=6 && board[row][column+2].playerPiece==player){
                if(column+3<=6 && board[row][column+3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToUpRight(char player, int row, int column){//test if there are 3 pieces to the left
        if(column+1<=6 && row-1>=0 &&board[row-1][column+1].playerPiece==player){
            if(column+2<=6 && row-2>=0 && board[row-2][column+2].playerPiece==player){
                if(column+3<=6 && row-3>=0 && board[row-3][column+3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToDownRight(char player, int row, int column){//test if there are 3 pieces to the left
        if(column+1<=6 && row+1<=5 &&board[row+1][column+1].playerPiece==player){
            if(column+2<=6 && row+2<=5 && board[row+2][column+2].playerPiece==player){
                if(column+3<=6 && row+3<=5 && board[row+3][column+3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToDownLeft(char player, int row, int column){//test if there are 3 pieces to the left
        if(column-1>=0 && row+1<=5 &&board[row+1][column-1].playerPiece==player){
            if(column-2>=0 && row+2<=5 && board[row+2][column-2].playerPiece==player){
                if(column-3>=0 && row+3<=5 && board[row+3][column-3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean threeToUpLeft(char player,int row, int column){
        if(column-1>=0 && row-1>=0 &&board[row-1][column-1].playerPiece==player){
            if(column-2>=0 && row-2>=0 && board[row-2][column-2].playerPiece==player){
                if(column-3>=0 && row-3>=0 && board[row-3][column-3].playerPiece==player){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean twoUpOneDown(char player,int row, int column){
        if( row-1>=0 &&board[row-1][column].playerPiece==player){
            if(row-2>=0 && board[row-2][column].playerPiece==player){
                if( row+1<6 && board[row+1][column].playerPiece==player){
                    return true;
                }
            }
        }
        //test if the one below has 2up1down
        if(row+1<6 && board[row+1][column].playerPiece==player){
            return twoUpOneDown(player,row+1,column);
        }
        return false;
    }

    private boolean twoLeftOneRight(char player,int row, int column){
        if( column-1>=0 &&board[row][column-1].playerPiece==player){
            if(column-2>=0 && board[row][column-2].playerPiece==player){
                if( column+1<6 && board[row][column+1].playerPiece==player){
                    return true;
                }
            }
        }

        if(column+1<=6 && board[row][column+1].playerPiece==player){
            return twoLeftOneRight(player,row,column+1);
        }
        return false;
    }

    private boolean middleDiagonal(char player, int row, int column){
        //        c
        //      c
        //    x
        //  c
        if( column-1>=0 && row+1<6 &&board[row+1][column-1].playerPiece==player){
            if(column+1<=6 && row-1>=0 && board[row-1][column+1].playerPiece==player){
                if( column+2<6 && row-2>=0 && board[row-2][column+2].playerPiece==player){
                    return true;
                }
            }
        }

        if(column-1>=0 && row+1<6 && board[row+1][column-1].playerPiece==player){
            return middleDiagonal(player,row+1,column-1);
        }
        return false;
    }

    private boolean middleDiagonalReverse(char player, int row, int column){
        //c
        //  c
        //    x
        //      c
        if( column+1<=6 && row+1<6 &&board[row+1][column+1].playerPiece==player){
            if(column-1>=0 && row-1>=0 && board[row-1][column-1].playerPiece==player){
                if( column-2<6 && row-2>=0 && board[row-2][column-2].playerPiece==player){
                    return true;
                }
            }
        }

        if(column+1<=6 && row+1<6 && board[row+1][column+1].playerPiece==player){
            return middleDiagonal(player,row+1,column+1);
        }
        return false;
    }

    }



