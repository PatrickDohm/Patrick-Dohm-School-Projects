public class ChessBoard extends AbstractBoard{

    ChessSquare board1[][];
    ChessSquare dummyboard[][];//this is used to show possible moves to the user
    ChessPieceControl pieceControl;
    //with the chess board, player 1 will have lower case letters, player 2 will have uppercase
    public ChessBoard(){
        super.row=8;
        super.column=8;
        board= new ChessSquare[row][column];
        dummyboard=new ChessSquare[row][column];

        board1= (ChessSquare[][])board;
        pieceControl=new ChessPieceControl(this);
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                board1[i][j]=new ChessSquare();
                dummyboard[i][j]=new ChessSquare();
            }
        }
        initStartingBoard();
        copyBoard();
    }

    private void copyBoard(){
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                char c=board1[i][j].getPlayerPiece();
                dummyboard[i][j].setPlayerPiece(c);
            }
        }
    }


    protected void printDummyBoard(){

        System.out.println("\n");//make sure the next board has space

        char columnHeader='A';
        int rowHeader=8;
        for(int j=0;j<row;j++){
            for(int i=0;i<column;i++){
                System.out.print("----------");
            }
            System.out.print("\n");
            System.out.print(rowHeader);
            rowHeader--;
            for(int i=0;i<column;i++){
                System.out.print(String.format("%-5s%-5c", "|", this.dummyboard[j][i].getPlayerPiece()));
            }
            System.out.print("|\n");

        }


        for(int i=0;i<row;i++){
            System.out.print("----------");
        }
        System.out.print("\n");
        System.out.print(" ");
        for(int i=0;i<column;i++){
            System.out.print(String.format("%-5s%-5c", "|", columnHeader));
            columnHeader++;
        }
        System.out.println("|\n");


    }


    @Override
    protected int placePiece(int playerTurn, int row, int column) {
        return 0;
    }
    protected boolean movePiece(row_column current, row_column move){
    //get possible moves then check if move is legal
        //return true if it moved successfully

            switch(board1[current.getRow()][current.getColumn()].getPlayerPiece()){
                case 'p':
                case 'P':
                    pieceControl.PawnMoves(current); break;
                case 'r':
                case 'R':
                    pieceControl.RookMoves(current); break;
                case 'n':
                case 'N':
                    pieceControl.KnightMoves(current); break;
                case 'b':
                case 'B':
                    pieceControl.BishopMoves(current); break;
                case 'q':
                case 'Q':
                    pieceControl.QueenMove(current); break;
                case 'k':
                case 'K':
                    pieceControl.KingMove(current); break;
            }
            if(dummyboard[move.getRow()][move.getColumn()].getPlayerPiece()=='*'){
                board1[move.getRow()][move.getColumn()].setPlayerPiece(board1[current.getRow()][current.getColumn()].getPlayerPiece());
                setClear(current);
                board1[move.getRow()][move.getColumn()].numberMoves=board1[current.getRow()][current.getColumn()].numberMoves+1;
                board1[current.getRow()][current.getColumn()].numberMoves=0;
                copyBoard();
                return true;
            }
        return false;

    }


    @Override
    protected boolean isWinner(int playerTurn, int row, int column) {
        //the turn change happens before I check this so if it returns true I will declare the other player the victor
        if(playerTurn==1){
            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='k'){
                        return false;
                    }
                }
            }
        }else if(playerTurn==2){
            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='K'){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    protected void initStartingBoard(){
        int n=0;
        int j=0;
        row_column square= new row_column();
        square.setRow(1);
        square.setPlayerTurn(1);
        for(int i=0; i<column;i++){//init some pawns
            square.setColumn(i);
            setPawn(square);
        }
        for(int i=1;i<3;i++){//init back rows
            square.setPlayerTurn(i);
            square.setRow(j);
            square.setColumn(n);
            setRook(square);
            n++;
            square.setColumn(n);
            setKnight(square);
            n++;
            square.setColumn(n);
            setBishop(square);
            n++;
            square.setColumn(n);
            setQueen(square);
            n++;
            square.setColumn(n);
            setKing(square);
            n++;
            square.setColumn(n);
            setBishop(square);
            n++;
            square.setColumn(n);
            setKnight(square);
            n++;
            square.setColumn(n);
            setRook(square);
            n=0;
            j=7;

        }
        square.setRow(6);
        square.setPlayerTurn(2);
        for(int i=0;i<column;i++){
            square.setColumn(i);
            setPawn(square);
        }
    }

    protected void setClear(row_column square){
        board1[square.getRow()][square.getColumn()].setPlayerPiece(' ');
    }

    protected void setPawn(row_column square){
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('p');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('P');
        }
    }

    protected void setRook(row_column square){
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('r');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('R');
        }
    }

    protected void setBishop(row_column square){
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('b');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('B');
        }
    }

    protected void setKnight(row_column square){//the king is k already
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('n');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('N');
        }
    }
    protected void setQueen(row_column square){
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('q');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('Q');
        }
    }
    protected void setKing(row_column square){
        if(square.getPlayerTurn()==1){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('k');
        }else if(square.getPlayerTurn()==2){
            board1[square.getRow()][square.getColumn()].setPlayerPiece('K');
        }
    }


    public void inCheck(row_column current) {
        row_column king= new row_column();
        row_column enemy=new row_column();
        if(current.getPlayerTurn()==2){
            //find king
            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='k'){
                        king.setColumn(j);
                        king.setRow(i);
                    }
                }
            }
           //check if anything can attack it
            king.setPlayerTurn(1);


            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='Q'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.QueenMove(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Queen has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='R'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.RookMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Rook has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='P'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.PawnMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Pawn has you in check... How did you mess up this badly??");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='B'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.BishopMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Bishop has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='K'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.KingMove(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy King has you in check, the enemy is throwing in the tower");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='N'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(2);
                        pieceControl.KnightMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Knight has you in check");
                        }
                    }
                    copyBoard();
                }
            }

        }else if(current.getPlayerTurn()==1){
            //find king
            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='K'){
                        king.setColumn(j);
                        king.setRow(i);
                    }
                }
            }
            //check if anything can attack it
            for(int i=0;i<8;i++){
                for(int j=0;j<8;j++){
                    if(board1[i][j].getPlayerPiece()=='q'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.QueenMove(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Queen has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='r'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.RookMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Rook has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='p'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.PawnMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Pawn has you in check... How did you mess up this badly??");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='b'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.BishopMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Bishop has you in check");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='k'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.KingMove(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy King has you in check, the enemy is throwing in the tower");
                        }
                    }else if(board1[i][j].getPlayerPiece()=='n'){
                        enemy.setColumn(j);
                        enemy.setRow(i);
                        enemy.setPlayerTurn(1);
                        pieceControl.KnightMoves(enemy);
                        if(dummyboard[king.getRow()][king.getColumn()].getPlayerPiece()=='*'){
                            System.out.println("The enemy Knight has you in check");
                        }
                    }
                    copyBoard();
                }
            }
        }

    }
}
