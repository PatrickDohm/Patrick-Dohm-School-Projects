public class ChessSquare extends Piece{
    int numberMoves;
    public ChessSquare(){
        setPlayerPiece(' ');
        numberMoves=0;
    }
    protected boolean legalMove(){
        return false;
    }




}
