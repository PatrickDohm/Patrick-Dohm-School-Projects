﻿using System;
using System.Collections;
using System.Text;
using System.Threading;
using GHIElectronics.TinyCLR.Devices.Display;
using System.Drawing;
using GHIElectronics.TinyCLR.Devices.Gpio;

using System.Diagnostics;

namespace TinyCLRApplication1
{
    class Program
    {
        static Graphics screen;
        static GpioPin led = GpioController.GetDefault().OpenPin(
        GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PC18);
        static int score=0;
        static int pickles_eaten = 0;


        static void Main()
        {
            var displayController = DisplayController.GetDefault();
            
            var font2 = Resource1.GetFont(Resource1.FontResources.arial2);

            // Enter the proper display configurations, KEEP AS IS
            displayController.SetConfiguration(new ParallelDisplayControllerSettings
            {
                Width = 480,
                Height = 272,
                DataFormat = DisplayDataFormat.Rgb565,
                PixelClockRate = 20000000,
                PixelPolarity = false,
                DataEnablePolarity = true,
                DataEnableIsFixed = false,
                HorizontalFrontPorch = 2,
                HorizontalBackPorch = 2,
                HorizontalSyncPulseWidth = 41,
                HorizontalSyncPolarity = false,
                VerticalFrontPorch = 2,
                VerticalBackPorch = 2,
                VerticalSyncPulseWidth = 10,
                VerticalSyncPolarity = false,
            });

            displayController.Enable();

            screen = Graphics.FromHdc(displayController.Hdc);
            var GreenPen = new Pen(Color.Green);

            //This draws the image
            // Start Drawing (to memroy)
            screen.Clear(Color.Black);
            screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Hello), 450/3,0 );

            //This draws words
            
            screen.DrawString("Press Up to Start", font2, new SolidBrush(Color.Green), 20, 250);
           
            
            // Flush the memory to the display. This is a very fast operation.
            screen.Flush();


            //Set up button control DO NOT TOUCH
            GpioPin padUp = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PA24);
            GpioPin padDown = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PA4);
            GpioPin padRight = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PD9);
            GpioPin padLeft = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PD7);
            //Thread.Sleep(5000);
            Enemy1.SetYlocation1();
            Enemy2.SetYlocation2();
            Enemy3.SetYlocation3();

            //CHANGE THIS TO WHAT YOU NEED
            while (padUp.Read() != 0)
            {
                Thread.Sleep(100);
            }
           
            while (true)
            {
                //the more points you score, the faster everything moves
                if (score < 100)
                {
                    player_move_speed = 10;
                    enemy_move_speed = 20;
                    screen.DrawString("Level 1 ", font2, new SolidBrush(Color.Green),400 ,40 );
                }
                else if(score>=100 && score < 400)
                {
                    player_move_speed = 10;
                    enemy_move_speed = 40;
                    screen.DrawString("Level 2", font2, new SolidBrush(Color.Green), 400, 40);
                }
                else
                {
                    player_move_speed = 10;
                    enemy_move_speed = 80;
                    screen.DrawString("Level 3", font2, new SolidBrush(Color.Green), 400, 40);
                }screen.Flush();
                


                if (padRight.Read() == 0)//move right
                {
                    if (Player.check_x() <= 480 - 20)
                        Player.set_x(player_move_speed);
                }
                else if (padLeft.Read() == 0)//move left
                {
                    if (Player.check_x() > 20)
                        Player.set_x(-player_move_speed);
                }
                else if (padUp.Read() == 0)//move up
                {
                    if (Player.check_y() > 20)
                    {
                        Player.set_y(-player_move_speed);
                    }
                }
                else if (padDown.Read() == 0)
                {//move down
                    if (Player.check_y() <= 272 - 40)
                    {
                        Player.set_y(player_move_speed);
                    }
                }
                Thread.Sleep(33);
                hit_detection();
                UpdateEnemies();
                UpdateScreen();

                //game over, press up to restart
                if (game_over())
                {
                    screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.game_over_screen), 450 / 3, 100);
                    screen.Flush();
                    while(padUp.Read() != 0)
                    {
                        Thread.Sleep(100);
                    }
                    pickles_eaten = 0;
                    score = 0;

                }

            }
        }
        static Enemy Enemy1 = new Enemy();
        static Enemy Enemy2 = new Enemy();
        static Enemy Enemy3 = new Enemy();
        static Player_Character Player = new Player_Character();
        static int player_move_speed = 10;
        static int enemy_move_speed = 30;
        static bool ledValue = false;
       
        static int EnemyLocationX = 0;//separate from enemy class because they should move together
        static void UpdateScreen() 
           
        {

           
            screen.Clear(Color.Black);
             screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Player), Player.check_x(),Player.check_y());
            //draw enemies
            if (Enemy1.Checkfoodp())//draw enemy1
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Image1), EnemyLocationX, Enemy1.Ylocation);
            }
            else
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Cheeseburger), EnemyLocationX, Enemy1.Ylocation);
            }


            if (Enemy2.Checkfoodp())//draw enemy 2
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Image1), EnemyLocationX, Enemy2.Ylocation);
            }
            else
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Cheeseburger), EnemyLocationX, Enemy2.Ylocation);
            }

            if (Enemy3.Checkfoodp())//draw enemy 3
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Image1), EnemyLocationX, Enemy3.Ylocation);
            }
            
            else
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Cheeseburger), EnemyLocationX, Enemy3.Ylocation);
            }

            //draw number of pickles eaten
            int tmp = pickles_eaten;
            int x = 30;
            while (tmp != 0)
            {
                screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Image1), x, 20);
                x += 30;
                tmp--;
            }

           
            var font2 = Resource1.GetFont(Resource1.FontResources.arial2);
            //draw score
            string total = "Your Score is ";
            screen.DrawString( total+score, font2, new SolidBrush(Color.White), 20, 250);
            
            screen.Flush();

            if (!ledValue)
            {
                led.Write(GpioPinValue.High);
                ledValue = true;
            }
            else
            {
                led.Write(GpioPinValue.Low);
                ledValue = false;
            }

        }

static Random rnd = new Random();

        static void UpdateEnemies()  {
            
            if (EnemyLocationX == 0)
            {
                
                int i = rnd.Next(7);//returns a number less than 7
                
                switch (i)
                {
                    case 0: Enemy1.SetFoodc(); Enemy2.SetFoodc(); Enemy3.SetFoodc();break;
                    case 1: Enemy1.SetFoodp();Enemy2.SetFoodc();Enemy3.SetFoodc(); break;
                    case 2: Enemy1.SetFoodc(); Enemy2.SetFoodp(); Enemy3.SetFoodc();break;
                    case 3: Enemy1.SetFoodc(); Enemy2.SetFoodc(); Enemy3.SetFoodp();break;
                    case 4: Enemy1.SetFoodc(); Enemy2.SetFoodp(); Enemy3.SetFoodp();break;
                    case 5: Enemy1.SetFoodp(); Enemy2.SetFoodp(); Enemy3.SetFoodc(); break;
                    case 6: Enemy1.SetFoodp(); Enemy2.SetFoodp(); Enemy3.SetFoodp(); break;
                }
                //randomize location of food
                int a, b, c;
                a = rnd.Next(220);
                while(a < 40) { a = rnd.Next(220); }
                b = rnd.Next(220);
                while (b < 40 || b == a) { b = rnd.Next(220); }//prevent overlap
                c = rnd.Next(220);
                while(c<40 || c==b || c == a) { c = rnd.Next(220); }
                Enemy1.SetY(a);
                Enemy2.SetY(b);
                Enemy3.SetY(c);


            }


            if (EnemyLocationX < 480)
            {
                EnemyLocationX += enemy_move_speed;
            }
            else
            {
                EnemyLocationX = 0;
            }

            
        }

        static void hit_detection()
        {
            if(Player.check_x()>= EnemyLocationX && Player.check_x()<=EnemyLocationX+25)//if the player is on the same x coordinate
            {
                //check enemy 1
                if (Player.check_y() >= Enemy1.Ylocation && Player.check_y()<=Enemy1.Ylocation+25)
                {
                    if (Enemy1.Checkfoodp())
                    {
                        pickles_eaten++;
                    }
                    else
                    {
                        score = score + 10;
                    }
                    EnemyLocationX = 0;//when something is hit reset the food
                }
                //check enemy 2
                if (Player.check_y() >= Enemy2.Ylocation && Player.check_y() <= Enemy2.Ylocation + 25)
                {
                    if (Enemy2.Checkfoodp())
                    {
                        pickles_eaten++;
                    }
                    else
                    {
                        score = score + 10;
                    }
                    EnemyLocationX = 0;//when something is hit reset the food
                }
                //check enemy 3
                if (Player.check_y() >= Enemy3.Ylocation && Player.check_y() <= Enemy3.Ylocation + 25)
                {
                    if (Enemy3.Checkfoodp())
                    {
                        pickles_eaten++;
                    }
                    else
                    {
                        score = score + 10;
                    }
                    EnemyLocationX = 0;//when something is hit reset the food
                }

            }
        }

        static bool game_over()
        {
            if (pickles_eaten == 6)
            {
                return true;
            }
            return false;
        }

        // Enter the proper display configurations
    }
}
