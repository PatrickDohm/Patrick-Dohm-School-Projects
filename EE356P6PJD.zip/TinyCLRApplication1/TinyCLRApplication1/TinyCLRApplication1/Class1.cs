﻿using System;
using System.Collections;
using System.Text;
using System.Threading;

namespace TinyCLRApplication1
{
    class Enemy//This is the enemy food class
    {
        public int Ylocation;
   
        char food;
   
        

        public Enemy()
        {
            food = 'b';
            Ylocation = 0;
        }

        public void SetFoodp()
        {
            food = 'p';
        }
        public int ylocation { get; set; }
        public char Food { get; set; }


        public bool Checkfoodp()
        {
            if (food == 'p')
            {
                return true;
            }
            return false;
        }

        public void SetFoodc()
        {
            food = 'c';
        }
        public bool Checkfoodc()
        {
            if (food == 'c')
            {
                return true;
            }
            return false;
        }
        public void SetYlocation3()
        {
            Ylocation = 200;
        }
        public void SetYlocation2()
        {
            Ylocation = 140;
        }
        public void SetYlocation1()
        {
            Ylocation = 80;
        }
        public void SetY(int x) {
            Ylocation = x;
        }
       
    }
}
