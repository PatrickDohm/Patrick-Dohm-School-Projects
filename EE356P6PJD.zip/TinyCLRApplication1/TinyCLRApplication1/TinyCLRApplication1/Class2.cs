﻿using System;
using System.Collections;
using System.Text;
using System.Threading;

namespace TinyCLRApplication1
{
    class Player_Character
    {
        private int xlocation;
        private int ylocation;

        public Player_Character()
        {
            xlocation = 450;
            ylocation = 272 / 2;
        }

        public int check_x()
        {
            return xlocation;
        }

        public void set_x(int x)
        {
            xlocation = xlocation + x;
        }
        public int check_y()
        {
            return ylocation;
        }
        public void set_y(int y)
        {
            ylocation = ylocation + y;
        }
    }
}
