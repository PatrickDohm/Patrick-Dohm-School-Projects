﻿using System;
using System.Collections;
using System.Text;
using System.Threading;

namespace TinyCLRApplication1
{
     class Enemy//This is the enemy food class
    {
       static int Ylocation;

        static char food;

        static Enemy()
        {
            food = 'b';
            Ylocation = 0;
        }

        static void SetFoodp()
        {
            food = 'p';
        }
        static bool Checkfoodp()
        {
            if (food == 'p')
            {
                return true;
            }
            return false;
        }

        static void SetFoodc()
        {
            food = 'c';
        }
        static bool Checkfoodc()
        {
            if (food == 'c')
            {
                return true;
            }
            return false;
        }
    }
}
