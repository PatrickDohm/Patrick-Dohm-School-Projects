﻿using System;
using System.Collections;
using System.Text;
using System.Threading;
using GHIElectronics.TinyCLR.Devices.Display;
using System.Drawing;
using GHIElectronics.TinyCLR.Devices.Gpio;

using System.Diagnostics;

namespace TinyCLRApplication1
{
    class Program
    {
        static Graphics screen;
        static GpioPin led = GpioController.GetDefault().OpenPin(
        GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PC18);

        static void Main()
        {
            var displayController = DisplayController.GetDefault();
            var font = Resource1.GetFont(Resource1.FontResources.arial);

            // Enter the proper display configurations, KEEP AS IS
            displayController.SetConfiguration(new ParallelDisplayControllerSettings
            {
                Width = 480,
                Height = 272,
                DataFormat = DisplayDataFormat.Rgb565,
                PixelClockRate = 20000000,
                PixelPolarity = false,
                DataEnablePolarity = true,
                DataEnableIsFixed = false,
                HorizontalFrontPorch = 2,
                HorizontalBackPorch = 2,
                HorizontalSyncPulseWidth = 41,
                HorizontalSyncPolarity = false,
                VerticalFrontPorch = 2,
                VerticalBackPorch = 2,
                VerticalSyncPulseWidth = 10,
                VerticalSyncPolarity = false,
            });

            displayController.Enable();

            screen = Graphics.FromHdc(displayController.Hdc);
            var GreenPen = new Pen(Color.Green);

            //This draws the image
            // Start Drawing (to memroy)
            screen.Clear(Color.Black);
            screen.DrawImage(Resource1.GetBitmap(Resource1.BitmapResources.Hello), 0, 0);

            //This draws words
            //screen.DrawEllipse(GreenPen, 10, 10, 20, 10);
            screen.DrawString("Press Up to Start", font, new SolidBrush(Color.Green), 20, 250);
           
            
            // Flush the memory to the display. This is a very fast operation.
            screen.Flush();


            //Set up button control DO NOT TOUCH
            GpioPin padUp = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PA24);
            GpioPin padDown = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PA4);
            GpioPin padRight = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PD9);
            GpioPin padLeft = GpioController.GetDefault().OpenPin(
            GHIElectronics.TinyCLR.Pins.G400D.GpioPin.PD7);
            int locationX = 450;
            //Thread.Sleep(5000);


            //CHANGE THIS TO WHAT YOU NEED
            while (padUp.Read() != 0)
            {
                Thread.Sleep(100);
            }
           
            while (true)
            {

                if (padRight.Read() == 0)//move right
                {
                    if (locationX <= 480 - 20)
                        locationX += 10;
                }
                else if (padLeft.Read() == 0)//move left
                {
                    if (locationX > 20)
                        locationX -= 10;
                }
                else if (padUp.Read() == 0)//move up
                {
                    if (locationY > 20)
                    {
                        locationY -= 10;
                    }
                }
                else if (padDown.Read() == 0)
                {//move down
                    if (locationY <= 272 -40)
                    {
                        locationY += 10;
                    }
                }
                Thread.Sleep(33);
                UpdateEnemies();
                UpdateScreen(locationX);

            }
        }
           Enemy  Enemy1 = new Enemy();
            Enemy Enemy2 = new Enemy();
             Enemy Enemy3 = new Enemy();
            
            
        static bool ledValue = false;
        static int locationY = 272/2;
        static int EnemyLocationX = 0;
         void UpdateScreen(int locationX) 
           
        {
            var GreenPen = new Pen(Color.Green);
            var purplepen = new Pen(Color.Purple);
            var orangepen = new Pen(Color.Yellow);
            screen.Clear(Color.Black);
            screen.DrawRectangle(GreenPen, locationX, locationY, 20, 20);
            if (Enemy1.Checkfood('p'))//draw enemy1
            {
                screen.DrawEllipse(purplepen, EnemyLocationX, Enemy1.Ylocation, 20, 20);
            }
            else
            {
                screen.DrawRectangle(orangepen, EnemyLocationX, Enemy1.Ylocation, 20, 20);
            }


            if (Enemy2.Checkfood('p'))
            {
                screen.DrawEllipse(purplepen, EnemyLocationX, Enemy2.Ylocation, 20, 20);
            }
            else
            {
                screen.DrawRectangle(orangepen, EnemyLocationX, Enemy2.Ylocation, 20, 20);
            }

            if (Enemy3.Checkfood('p'))
            {
                screen.DrawEllipse(purplepen, EnemyLocationX, Enemy3.Ylocation, 20, 20);
            }
            else
            {
                screen.DrawRectangle(orangepen, EnemyLocationX, Enemy3.Ylocation, 20, 20);
            }
            screen.Flush();

            if (!ledValue)
            {
                led.Write(GpioPinValue.High);
                ledValue = true;
            }
            else
            {
                led.Write(GpioPinValue.Low);
                ledValue = false;
            }

        }

        static void UpdateEnemies()  {
            if (EnemyLocationX == 0)
            {
                Random rnd = new Random();
                int i = rnd.Next(3);
                switch (i)
                {
                    case 0: Enemy1.SetFoodc(); Enemy2.SetFoodc(); Enemy3.SetFoodc();break;
                    case 1: Enemy1.SetFoodp();Enemy2.SetFood('c');Enemy3.SetFood('c'); break;
                    case 2: Enemy1.SetFood('c'); Enemy2.SetFood('p'); Enemy3.SetFood('c');break;
                    case 3: Enemy1.SetFood('c'); Enemy2.SetFood('c'); Enemy3.SetFood('p');break;
                }

            }


            if (EnemyLocationX < 480)
            {
                EnemyLocationX += 20;
            }
            else
            {
                EnemyLocationX = 0;
            }
        }

        // Enter the proper display configurations
    }
}
