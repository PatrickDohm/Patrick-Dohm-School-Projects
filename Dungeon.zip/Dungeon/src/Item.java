import java.io.*;

public class Item {

    protected String name;//name that appears when you pick item up or it is in your inventory
    protected File description;
    protected File examine;
    public Item(){

    }
    public Item(String name, String path, String examinePath){
        this.name=name;
        this.description=new File(path);
        this.examine=new File(examinePath);
    }
    protected boolean exists(){
        if(name !=""){
            return true;
        }
        return false;
    }

    protected void printDescription(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(description));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line).append("\n");
                line = br.readLine();
            }String fileAsString = sb.toString();
            System.out.println(fileAsString);
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    protected void examine(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(examine));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line).append("\n");
                line = br.readLine();
            }String fileAsString = sb.toString();
            System.out.println(fileAsString);
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }



}
