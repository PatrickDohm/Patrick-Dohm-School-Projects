import java.io.*;
import java.util.Scanner;

public class main {
    public static void main(String args[]){
        //Initialize Rooms
        Room Farm= new Room("Farm", "FARMdescription.txt",true,true,false,false);

        Room ElectricAvenue = new Room("Electric Avenue", "ELECTRICAVENUEdescription.txt",false,
                false,true,true);
        Room Stable= new Room("Stable","STABLEdescription.txt", false,false,false,true);
        Room OldTownRoad= new Room("Old Town Road", "OLDTOWNROADdescription.txt", false, true,
                false, false);
        Item UnstableKey= new Item("UnstableKey", "UNSTABLEKEYdescription.txt", "UNSTABLEKEYexamine.txt");
        Farm.addItem(UnstableKey);
        Item Stabilizer= new Item("Stabilizer","STABLIZERdescription.txt","STABALIZERexamine.txt" );
        ElectricAvenue.addItem(Stabilizer);

        Farm.setConnected("North", ElectricAvenue);//Set how Rooms are connected
        Farm.setConnected("East", Stable);
        ElectricAvenue.setConnected("South", Farm);
        ElectricAvenue.setConnected("West", OldTownRoad);
        OldTownRoad.setConnected("East", ElectricAvenue);
        Stable.setConnected("West", Farm);

        //initialize Player
        Player player=new Player(Farm);//start in the farm

        printOpening();
        player.getCurrentRoom().printRoom();
        //scanner used for reading input from console
        Scanner sc = new Scanner(System.in);
        String[] input = new String[4];
        input[0]="";
        while(true){
            try{
            input = sc.nextLine().split(" ");//this will read the input from the user and decide what to do


            //moving the character
            if(input[0].contains("East") || input[0].equals("e")){
                player.setCurrentRoom("East");
            }else if(input[0].contains("West") || input[0].equals("w")){
                player.setCurrentRoom("West");
            }else if(input[0].contains("North") || input[0].equals("n")){
                player.setCurrentRoom("North");
            }else if(input[0].contains("South") || input[0].equals("s")){
                player.setCurrentRoom("South");
            }else if(input[0].contains("pick") && input[1].contains("up")){ //pick up item
                player.getInventory().add(player.getCurrentRoom().item);
            }else if(input[0].contains("use")){
                if(player.getInventory().use(player.getInventory().contains(input[1]))){//this will print if they have the item or not
                    if(input[1].contains("StableKey") && player.getCurrentRoom()==Stable){
                        player.getInventory().add(new Item("Horse", "HORSEdescription.txt",
                                "HORSEexamine.txt"));
                    }else if(input[1].contains("Horse") && player.getCurrentRoom()==OldTownRoad){//if they ride their horse on the old town road they win
                        System.out.println("You Win\n");
                        System.exit(0);
                    }else{
                        System.out.println("The item had no effect\n");
                    }
                }
            } else if (input[0].contains("Take") && input[1].contains("it") && input[2].contains("higher")  // Secret
                && player.getCurrentRoom()==ElectricAvenue) {
                System.out.println("Found a secret. Is this worth extra credit???");
            }else if(input[0].contains("Talk")){    //talk to person in stable
                if(player.getCurrentRoom()==Stable){
                    printFile("PERSONdialogue.txt");
                }
            }else if (input[0].contains("Help")){
                printFile("HelpDocument.txt");
            }else if (input[0].contains("examine")){
                player.getInventory().examine(player.getInventory().contains(input[1]));
            }else if(input[0].contains("drop")){
                player.getInventory().drop(player.getInventory().contains(input[1]));
            }else if(input[0].contains("combine")){
                player.combine(player.getInventory().contains(input[1]), player.getInventory().contains(input[2]));
            }else if (input[0].contains("exit")){
                System.exit(0);
            }else if(input[0].contains("List")){
                player.getInventory().list_Inventory();
            }else if(input[0].contains("Location")){
                player.getCurrentRoom().setFirstTime(true);
                player.getCurrentRoom().printRoom();
            }else{
                System.out.println("Invalid input, Type Help to list commands\n");
            }

        }catch(ArrayIndexOutOfBoundsException e){
                System.out.println("Invalid input, Type Help to list commands\n");
            }
        }


    }

    private static void printOpening(){//this prints the opening text
        File opening=new File("OPENINGTEXT.txt");
        try{//print the opening
            BufferedReader br = new BufferedReader(new FileReader(opening));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line).append("\n");
                line = br.readLine();
            }String fileAsString = sb.toString();
            System.out.println(fileAsString);
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void printFile(String name){
        File newFile= new File(name);
        try{//print the opening
            BufferedReader br = new BufferedReader(new FileReader(newFile));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line).append("\n");
                line = br.readLine();
            }String fileAsString = sb.toString();
            System.out.println(fileAsString);
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}
