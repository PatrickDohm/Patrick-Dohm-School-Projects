public class Player {


    private Room currentRoom;
    private Inventory inventory= new Inventory();//start out with empty inventory

    public Player(Room currentRoom){
        this.currentRoom=currentRoom;//sets the starting room for the player
    }

   public void combine(Item item1, Item item2){
        if( inventory.item.contains(item1) && inventory.item.contains(item2)){
            if(item1.name.contains("UnstableKey") && item2.name.contains("Stabilizer")){
                inventory.add(new Item("StableKey", "STABLEKEYdescription.txt",
                        "STABLEKEYexamine.txt"));
                System.out.println("You have successfully combined the two items\n");
            }else{
                System.out.println("Those two items just don't want to combine\n");
            }
        }
   }

    public Room getCurrentRoom() {
        return currentRoom;
    }
    public void setCurrentRoom(String direction){//move the player from room to room and print description
        currentRoom=currentRoom.move(direction);
        currentRoom.printRoom();

    }
    public Inventory getInventory(){
        return inventory;
    }
}
