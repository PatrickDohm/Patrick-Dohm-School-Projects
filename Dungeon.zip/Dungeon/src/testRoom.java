//import junit.framework.Assert;
//import org.junit.Test;
//
//public class testRoom {
//    @Test
//    public void testRoom(){
//        Room Farm= new Room("Farm", "FARMdescription.txt",true,true,false,false);
//        Assert.assertEquals(Farm.getFirstTime(), true);
//        Assert.assertEquals(Farm.name,"Farm");
//        Farm.setFirstTime(false);
//        Assert.assertEquals(Farm.getFirstTime(), false);
//        Farm.setFirstTime(true);
//        Farm.printRoom();
//    }
//}
