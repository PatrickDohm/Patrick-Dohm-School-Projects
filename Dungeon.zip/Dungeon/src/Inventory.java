import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Inventory {
    ArrayList<Item> item= new ArrayList<Item>();
    public Inventory(){

    }

    public void add(Item newObject){
        if(item.contains(newObject)){
            System.out.println("You already have this item\n");
        }else{
            item.add(newObject);
            System.out.println(newObject.name+" has been added to your inventory\n");
        }
    }

    public boolean use(Item useObject){
        if(item.contains(useObject)){
            System.out.println("You used " + useObject.name);
            return true;
        }else{
            System.out.println("You don't have that item\n");
            return false;
        }
    }

    public void examine(Item examineObject){
        if(item.contains(examineObject)){
            System.out.println("You examined the item\n");
            examineObject.examine();
        }else{
            System.out.println("You don't have that item\n");
        }
    }

    public void drop(Item droppedItem){
        if(item.contains(droppedItem)){
            System.out.println("You dropped the item\n");
            System.out.println("If you want the item back, you need to go to the room you picked it up in\n");
            item.remove(droppedItem);
        }else{
            System.out.println("You don't have that item\n");
        }
    }

    public Item contains(String itemName){//This is messing up
        for(Item each : item){
            if(each.name.equals(itemName)){
                return each;
            }
        }
        return null;
    }
    public void list_Inventory(){
        for(Item each : item){
            System.out.print(each.name + "\n");
            }
        }
    }

