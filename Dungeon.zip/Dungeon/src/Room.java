import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Room {
    protected String name;
    private File description;
    private boolean North;
    private boolean East;
    private boolean South;
    private boolean West;
    private Room NorthRoom;
    private Room EastRoom;
    private Room SouthRoom;
    private Room WestRoom;
    protected Item item;
    protected boolean firstTime; //if first time equals true then the description for the room will write
    public Room(){
        name="";
        North=false;
        East=false;
        South=false;
        West=false;
        firstTime=true;
    }
    public Room(String name, String path, boolean North, boolean East, boolean South, boolean West){
        this.name=name;
        this.North=North;
        this.East=East;
        this.South=South;
        this.West=West;
        description=new File(path);
        firstTime=true;
    }

    protected void setFirstTime(boolean a){
        firstTime=a;
    }
    protected boolean getFirstTime(){
        return firstTime;
    }

    protected void addItem(Item item){
        this.item=item;
    }

    protected void printRoom(){
        System.out.println(name);   //print out room name
        if(firstTime){  //print out the long description if firstTime==true
            try{
                BufferedReader br = new BufferedReader(new FileReader(description));
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                while (line != null) {
                    sb.append(line).append("\n");
                    line = br.readLine();
                }String fileAsString = sb.toString();
                System.out.println(fileAsString);
            }catch (FileNotFoundException e) {
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }

            try {
                item.printDescription();
            }catch(NullPointerException e){

            }
            firstTime=false;

        }


    }

    protected Room move(String direction){
        if(direction=="East" && East==true){
            return EastRoom;
        }else if(direction=="South" && South==true){
            return SouthRoom;
        }else if(direction=="West" && West==true){
            return WestRoom;
        }else if (direction=="North" && North==true){
            return NorthRoom;
        }else{
            System.out.println("Hey Panini, You can't go that way\n");
            return this;
        }
    }

    protected void setConnected(String direction, Room room){//shows how rooms are connected
        if (direction=="East"){
            this.EastRoom=room;
        }else if(direction=="North"){
            this.NorthRoom=room;
        }else if(direction=="South"){
            this.SouthRoom=room;
        }else if(direction=="West"){
            this.WestRoom=room;
        }
    }
}
