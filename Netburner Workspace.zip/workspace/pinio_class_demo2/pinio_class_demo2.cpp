#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <pins.h>

extern "C" { void UserMain (void *pd); }

void UserMain (void *pd)
{

  OSChangePrio (MAIN_PRIO);
  J2[15].function(PINJ2_PD_GPIO);//J2 15 controls LED 1
  J2[13].function(PINJ2_PD_GPIO); //J2 13 controls dipsw 8
  iprintf ("Application started\n");
  while (1)
    {
	  J2[15]=!(J2[13].read());
      OSTimeDly(1/10*TICKS_PER_SECOND);

    }
}
