#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>

extern "C" { void UserMain(void * pd); }
OS_SEM sem_id;
OS_MBOX Mbox;
void TaskCode1(void *d)
{
	BYTE status;
	status= OSSemPost(&sem_id);
	int data = (int)d;
	int32_t count=0;
	while(1) {

        iprintf("Hello from Task %d\n", data);
        status= OSMboxPost(&Mbox, (void*) count);
        if(status != OS_NO_ERR){
        	iprintf("Error posting count to the MBOX\n");
        	exit(1);
        }
        count++;
		OSTimeDly(2*TICKS_PER_SECOND);
	}
}
void TaskCode2(void *d)
{
	BYTE status;
	int data = (int)d;
	int count;

	while(1) {

      count= (int)OSMboxPend(&Mbox, 0, &status);
      if(status !=OS_NO_ERR){
    	  iprintf("task 2 failed to recieve from Mbox\n");
    	  exit(1);
      }
      iprintf("count= %d\n", count);


	}
}

DWORD TaskStacks[2][USER_TASK_STK_SIZE] __attribute__((aligned(4)));

void UserMain(void * pd)
{
    BYTE status;

    OSChangePrio(MAIN_PRIO);

	status = OSTaskCreate(TaskCode1, (void *)1,
				&TaskStacks[0][USER_TASK_STK_SIZE],
				&TaskStacks[0][0], MAIN_PRIO+1);
	if(status != OS_NO_ERR) {
		iprintf("Error creating Task 1\n");
		exit(1);
	}

	status = OSTaskCreate(TaskCode2, (void *)2,
				&TaskStacks[1][USER_TASK_STK_SIZE],
				&TaskStacks[1][0], MAIN_PRIO+2);
	if(status != OS_NO_ERR) {
		iprintf("Error creating Task 2\n");
		exit(1);
	}

	status= OSSemInit(&sem_id, 0);
	if(status != OS_NO_ERR){
		iprintf("Error creating semaphore\n");
				exit(1);
	}
	status= OSMboxInit(&Mbox,NULL );
	if(status != OS_NO_ERR){
		iprintf("Error creating Message box\n");
		exit(1);
	}

    iprintf("Application started\n");
}
