#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>

extern "C" { void UserMain(void * pd); }
OS_SEM sem_id;
void TaskCode1(void *d)
{
	BYTE status;
	status= OSSemPost(&sem_id);
	int data = (int)d;
	while(1) {
		status=OSSemPend(&sem_id,0);
		if(status != OS_NO_ERR){
			iprintf("task 1 failed to acquire the semaphore");
			exit(1);
		}
        iprintf("Hello from Task %d\n", data);
        status= OSSemPost(&sem_id);
        if(status != OS_NO_ERR){
        	iprintf("task 1 failed to release semaphore");
        	exit(1);
        }
		OSTimeDly(2*TICKS_PER_SECOND);
	}
}
void TaskCode2(void *d)
{
	BYTE status;
	int data = (int)d;
	while(1) {
		status=OSSemPend(&sem_id,0);
        if(status != OS_NO_ERR){
        	iprintf("task 2 failed to release semaphore");
        	exit(1);
        }
        iprintf("Hello from Task %d\n", data);
        status= OSSemPost(&sem_id);

	}
}

DWORD TaskStacks[2][USER_TASK_STK_SIZE] __attribute__((aligned(4)));

void UserMain(void * pd)
{
    BYTE status;

    OSChangePrio(MAIN_PRIO);

	status = OSTaskCreate(TaskCode1, (void *)1,
				&TaskStacks[0][USER_TASK_STK_SIZE],
				&TaskStacks[0][0], MAIN_PRIO+1);
	if(status != OS_NO_ERR) {
		iprintf("Error creating Task 1\n");
		exit(1);
	}

	status = OSTaskCreate(TaskCode2, (void *)2,
				&TaskStacks[1][USER_TASK_STK_SIZE],
				&TaskStacks[1][0], MAIN_PRIO+2);
	if(status != OS_NO_ERR) {
		iprintf("Error creating Task 2\n");
		exit(1);
	}

	status= OSSemInit(&sem_id, 0);
	if(status != OS_NO_ERR){
		iprintf("Error creating semaphore\n");
				exit(1);
	}

    iprintf("Application started\n");
}
