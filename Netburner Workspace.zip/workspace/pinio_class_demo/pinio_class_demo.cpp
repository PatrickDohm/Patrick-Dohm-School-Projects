#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <pins.h>

extern "C" { void UserMain (void *pd); }

void UserMain (void *pd)
{
  int n = 0;
  OSChangePrio (MAIN_PRIO);
  J2[15].function(PINJ2_44_GPIO);//J2 15 controls LED 1
  iprintf ("Application started\n");
  while (1)
    {
	  J2[15].clr();
      OSTimeDly(3*TICKS_PER_SECOND);
      J2[15].set();
      OSTimeDly(1*TICKS_PER_SECOND);
    }
}
