#include <predef.h>
#include <stdio.h>
#include <ctype.h>
#include <startnet.h>
#include <autoupdate.h>
#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <ip.h>
#include <autoupdate.h>
#include<iosys.h>
#include <string.h>
#include<system.h>
#include <tcp.h>

extern "C" {
void UserMain(void * pd);
}
const int MYBUFSIZ = 128;
const int TSZ = USER_TASK_STK_SIZE;
DWORD TS[4][TSZ] __attribute__((aligned(4)));
OS_SEM nTasksSem;
OS_Q fdQueue;
int QData[4];

const char * AppName="NBMultiServer.cpp";

void ServerCode(void *d){
	BYTE err;
	int n,cli_fd;
	char buffer[MYBUFSIZ];

	while(1){
		//get client fd from fifo, block if client not available
		cli_fd = (int)OSQPend(&fdQueue, 0 ,&err);
		while(1){
			n=read(cli_fd, buffer, MYBUFSIZ);
			//NetBurner read returns -3 when socket is closed
			if(n<0){
				break;
			}
			buffer[n]='\0';
			strupr(buffer);
			write(cli_fd, buffer, n);
		}
		close(cli_fd);
		//Release semaphore to indicate that this task is now free
		OSSemPost(&nTasksSem);
	}
}

void UserMain(void * pd) {
	int lis_fd, cli_fd;
    InitializeStack();
    OSChangePrio(MAIN_PRIO);
    EnableAutoUpdate();

    iprintf("Application started\n");
    OSTaskCreate(ServerCode, (void *)0, &TS[0][TSZ], &TS[0][0], MAIN_PRIO+1);
    OSTaskCreate(ServerCode, (void *)0, &TS[1][TSZ], &TS[1][0], MAIN_PRIO+2);
    OSTaskCreate(ServerCode, (void *)0, &TS[2][TSZ], &TS[2][0], MAIN_PRIO+3);
    OSTaskCreate(ServerCode, (void *)0, &TS[3][TSZ], &TS[3][0], MAIN_PRIO+4);

    OSSemInit(&nTasksSem, 4);
    OSQInit(&fdQueue, (void **) QData,4);

    //Set up listening queue
    lis_fd = listen(INADDR_ANY, HTONS(10000), 5);
    while(1){
    	//check semaphore to see if a task is free
    	OSSemPend(&nTasksSem, 0);

    	iprintf("waiting on client\n");
    	cli_fd=accept(lis_fd, NULL,NULL,0);
    	iprintf("Client accepted\n");

    	//push cli_fd onto fifo
    	OSQPost(&fdQueue, (void*) cli_fd);
    }


}
