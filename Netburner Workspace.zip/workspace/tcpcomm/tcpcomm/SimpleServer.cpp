// Cross platform (Windows, Linux) simple network server
// Windows - MSYS, MSYS2, Cygwin
// Windows uses recv/send instead of read/write

#include "SimpleUtils.h"

using namespace std;

#define LISTEN_PORT  10000

int main()
{
   int err_ret;
   bool shutdown = false;
   const int BUFFSIZE = 256;

   sockInit();

   int accSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
   if(accSock == -1)
      error_exit("error: socket call");

   struct sockaddr_in srvAddr;
   srvAddr.sin_family = AF_INET;
   srvAddr.sin_port = htons(LISTEN_PORT);
   srvAddr.sin_addr.s_addr = INADDR_ANY;
   err_ret = bind(accSock, (struct sockaddr *)&srvAddr, sizeof(srvAddr));
   if(err_ret == -1)
      error_exit("error: bind call");

   err_ret = listen(accSock, 5);
   if(err_ret == -1)
      error_exit("error: listen call");

   cout << "SimpleServer: Listening on port " << LISTEN_PORT << endl;

   while(true)
   {
      int cliSock = accept(accSock, NULL, NULL);
      if(cliSock == -1)
         error_exit("error: accept call");

      cout << "SimpleServer: Client accepted" << endl;

      int nread;
      char buffer[BUFFSIZE];
      while (true)
      {
         nread = recv(cliSock, buffer, BUFFSIZE, 0);
         if (nread == 0)
         {
            // Socket closed
            break;
         }
	 if (strncmp("xxx", buffer, 3) == 0)
         {
	    shutdown = true;
	    break;
	 }
         for(int i=0; i<nread; i++)
         {
            buffer[i] = toupper(buffer[i]);
         }
         send(cliSock, buffer, nread, 0);
       }
       sockClose(cliSock);
       cout << "SimpleServer: Client disconnected" << endl;
       if(shutdown)
          break;
   }
   sockClose(accSock);
   sockCleanup();
   
   return 0;
}
