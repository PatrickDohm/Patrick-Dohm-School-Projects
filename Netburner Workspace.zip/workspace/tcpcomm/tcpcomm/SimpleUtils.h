#include <iostream>
#include <cstdlib>
#include <cstring>
#if defined __MINGW32__
#include <winsock.h>
#else
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

void error_exit(const char *err_str);

void sockInit();
void sockClose(int s);
void sockCleanup();

