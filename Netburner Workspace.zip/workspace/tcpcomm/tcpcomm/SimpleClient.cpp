// Cross platform (Windows, Linux) simple network client
// Windows - MSYS, MSYS2, Cygwin
// Windows uses recv/send instead of read/write

#include "SimpleUtils.h"

using namespace std;

int main(int argc, char *argv[])
{
    int err_ret, nread;
    string buffer;
    const int BUFFSIZE = 256;
    char cbuffer[BUFFSIZE];

    if (argc != 3)
        error_exit("error: SimpleClient IPADDR PORT");
         
    sockInit();

    int srvSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(srvSock == -1)
        error_exit("error: socket call");

    struct sockaddr_in srvAddr;
    srvAddr.sin_family = AF_INET;
    srvAddr.sin_port = htons(atoi(argv[2]));
    srvAddr.sin_addr.s_addr = inet_addr(argv[1]);
    cout << "Client attempting to connect to server: " 
	 << inet_ntoa(srvAddr.sin_addr) <<":" 
	 << ntohs(srvAddr.sin_port) << endl;
    err_ret = connect(srvSock, (struct sockaddr *)&srvAddr, sizeof(srvAddr));
    if (err_ret == -1)
        error_exit("error: connect call");

    cout << "Client connected to server" << endl;
    cout << "Enter . to end session." << endl;
    while(true)
    {
		do {
			cout << "> ";
			getline(cin, buffer);
			nread = buffer.length();
		} while (nread == 0);
        if(nread==1 && buffer[0]=='.')
            break;
        send(srvSock, buffer.c_str(), nread, 0);
        nread = recv(srvSock, cbuffer, BUFFSIZE, 0);
        if(nread == 0)
        {
           break;
        }
        cbuffer[nread] = '\0';
        cout << cbuffer << endl;
    }

    cout << "Closing connection to server." << endl;
    sockClose(srvSock);
    sockCleanup();

    return 0;
}

