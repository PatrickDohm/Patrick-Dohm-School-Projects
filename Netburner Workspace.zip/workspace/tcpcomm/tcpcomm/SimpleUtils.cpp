// All platform differences are handled here.

#include "SimpleUtils.h"

using namespace std;

void error_exit(const char *err_str)
{
    cerr << err_str << endl;
    exit(1000);
}

void sockInit()
{
#if defined __MINGW32__
    // Initialize Winsock
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR) 
        error_exit("error: WSAStartup");
#endif
}

void sockClose(int srvSock)
{
#if defined __MINGW32__
    closesocket(srvSock);
#else    
    close(srvSock);
#endif
}

void sockCleanup()
{
#if defined __MINGW32__
    WSACleanup();
#endif
}
