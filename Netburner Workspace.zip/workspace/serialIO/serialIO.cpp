#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <ip.h>
#include <autoupdate.h>
#include<iosys.h>
#include <cstring>

extern "C" { void UserMain (void *pd); }

void UserMain (void *pd)
{
	InitializeStack();
	EnableAutoUpdate();

  OSChangePrio (MAIN_PRIO);

  iprintf ("Application started\n");
  char str1[100];
int n=0;
  //FINISH LATER
  while(1){
	  char str[]=">";
	  write(1,str, strlen(str) );
	  n=read(0,str1,99 );
	  str1[n-1]='\n';
	  write(1, str1,strlen(str1)-1);
  }


}
