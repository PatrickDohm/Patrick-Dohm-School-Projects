#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>

extern "C" { void UserMain (void *pd); }

void UserMain (void *pd)
{
  int n = 0;
  OSChangePrio (MAIN_PRIO);

  iprintf ("Application started\n");
  while (1)
    {
      iprintf ("Hello there ... %d\n", n++);
      OSTimeDly (20);
    }
}
