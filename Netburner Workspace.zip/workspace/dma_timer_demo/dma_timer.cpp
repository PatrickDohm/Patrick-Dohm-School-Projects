/**********************************************************************
* This example program exercises one of the DMA timer modules to be   *
* used to generate a 50-microsecond resolution interrupt for the      *
* MCF5270 CPU. A counter is displayed every second via the debug      *
* serial port in MTTTY on how many interrupts are being generated,    *
* which is almost 20,000 times per second.                            *
**********************************************************************/
#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <ucos.h>
#include <constants.h>
#include <..\MOD5270\system\sim5270.h>	// For access to DMA timer regs
#include <cfinter.h>		// For utilizing interrupts

// Function prototypes - Instruct the C++ compiler not to mangle the
// function names
extern "C"
{
	void UserMain (void *pd);
}

//
// This function sets up the 5270 interrupt controller
//
void SetIntc (long func, int vector, int level, int prio);

DWORD uint32_counter = 0;	// Initialize interrupt counter
///////////////////////////////////////////////////////////////////////
// INTERRUPT() - Interrupt service routine. Take note that when the
// DTIM0 interrupt is initialized via SetIntc() in UserMain(), it is
// configured to be a level 1 interrupt, while the INTERRUPT() macro
// below specifies in the input parameter that all interrupts at level
// 6 and below are blocked. Once INTERRUPT() is entered after the
// level 1 DTIM0 interrupt is triggered, level 6 and below interrupts
// are blocked during the execution of this service routine until
// INTERRUPT() exits.

INTERRUPT (func_isr, 0x2600)
{
	sim.timer[0].ter |= 0x02;	// Clear the DTIM0 reference event flag
	uint32_counter++;		// Increment interrupt counter
}

///////////////////////////////////////////////////////////////////////
// UserMain() - Main task
//
void
UserMain (void *pd)
{
	OSChangePrio (MAIN_PRIO);
	iprintf ("Application started\r\n");
	////////////////////////////////////////////////////////////////////
	// Initialize DMA timer registers (refer to MCF5271 Reference Manual
	// Section 22.2 for descriptions on the bit configurations of the
	// registers).
	//
	// To calculate the time-out period for the interrupt interval, the
	// following formula from Section 22.3.2 (Calculating Time-Out
	// Values) is used:
	//
	// T = Time-out period in seconds
	// DIVIDER = 1 or 16 (set via Mode Register [CLK])
	// PRESCALAR = 1 (0x00) to 256 (0xFF) (set via Mode Register
	// [PS])
	// REF_COMP_VAL = Reference compare value (set via 32-bit Reference
	// Register)
	//
	// T = ( 1 / CLOCKFREQ ) * DIVIDER * ( PRESCALAR + 1 ) *
	// ( REF_COMP_VAL + 1 )
	//
	// To get 0.00005 second (50 microseconds) as the interrupt interval
	// in this example, the following is used:
	//
	// 0.00005 = ( 1 / 73728000 ) * 1 * ( 0 + 1 ) * ( 3685 + 1 )
	//
	// CLOCKFREQ = 73,728,000 Hz is used for CLKOUT, which is half of
	// the internal system clock (147,456,000 Hz)
	// DIVIDER = 1 (set as "01" in Mode Register [CLK] bits 2-1)
	// PRESCALAR = 1 (set as "0000 0000" in Mode Register [PS] bits
	// 15-8)
	// REF_COMP_VAL = 3685 (set in 32-bit Reference Register - an
	// interrupt will occur when the Counter Register
	// value matches the set reference compare value
	// before the counter resets)
	//
	//
	// DMA Timer 0 Mode Register - Refer to Table 22-2 to see what each
	// of the bits are configuring.
	//
	sim.timer[0].tmr = 0x001A;	// 0000 0000 0001 1010
	//
	// DMA Timer 0 Extended Mode Register - Refer to Table 22-3; DMA
	// requests disabled and timer increments by 1.
	//
	sim.timer[0].txmr = 0x00;	// 0000 0000
	//
	// DMA Timer 0 Timer Event Register - Refer to Table 22-4; clears
	// the DTIM0 output reference event flag.
	//
	sim.timer[0].ter |= 0x02;	// 0000 0010
	//
	// DMA Timer 0 Timer Reference Register - This is where the
	// calculated REF_COMP_VAL is used for interval timing.
	//
	// 50 us = (1/73,728,000) *(trr + 1) implies trr = 3685
	sim.timer[0].trr = 73727;

	//
	// DMA Timer 0 Timer Counter Register - Any writing to this register
	// clears the counter; done just to be thorough, though not
	// necessary.
	//
	sim.timer[0].tcn = 1;		// Clear counter
	SetIntc ((long) &func_isr, 19, 1, 1);	// Set the ISR and
	// source vector
	sim.timer[0].tmr |= 0x0001;	// Enable the DMA timer
	while (1)
	{
		OSTimeDly (TICKS_PER_SECOND);
		iprintf ("DTIM0 Count = %ld\r\n", uint32_counter);
	}
}
