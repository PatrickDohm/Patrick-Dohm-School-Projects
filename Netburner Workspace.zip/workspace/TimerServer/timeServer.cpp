#include <predef.h>
#include <stdio.h>
#include <ctype.h>
#include <startnet.h>
#include <autoupdate.h>
#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <ip.h>
#include <autoupdate.h>
#include<iosys.h>
#include <string.h>
#include<system.h>
#include <tcp.h>
#include <rtc.h>
#include <time.h>

extern "C" {
void UserMain(void * pd);
}
const int MYBUFSIZ = 128;
const int TSZ = USER_TASK_STK_SIZE;
DWORD TS[4][TSZ] __attribute__((aligned(4)));
const char * AppName="timeServer";
OS_SEM nTasksSem;
OS_Q fdQueue;
int QData[4];


struct tm *TIME;

void ServerCode(void *d){
	BYTE err;
	int n,cli_fd, test;
	char buffer[MYBUFSIZ];
	while(1){
			//get client fd from fifo, block if client not available
			cli_fd = (int)OSQPend(&fdQueue, 0 ,&err);
			while(1){
				n=read(cli_fd, buffer, MYBUFSIZ);
				//NetBurner read returns -3 when socket is closed
				if(n<0){
					break;
				}
				if(buffer[0]== 's' && buffer[1]=='t'){
					int month=0;
					int year=0;
					int day=0;
					int hour=0;
					int minute=0;
					int second=0;
					sscanf(buffer, "st %2d/%2d/%4d %2d:%2d:%2d",&month,&day,&year,&hour,&minute,&second);
					TIME->tm_mon=month-1;
					TIME->tm_mday=day;
					TIME->tm_year=year;
					TIME->tm_hour=hour;
					TIME->tm_min=minute;
					TIME->tm_sec=second;
					TIME->tm_isdst=0;
					TIME->tm_wday=0;
					TIME->tm_yday=0;
					test=RTCSetTime(*TIME);
					if(test!=0){
						iprintf("RTCSetTime failed\n");
					}else{
						sprintf(buffer, "Set successfully\n");
						write(cli_fd, buffer, n);
					}

				}else if(buffer[0]=='g' && buffer[1]=='t'){
					test= RTCGetTime( *TIME );
					if(TIME->tm_hour<=12){
						sprintf(buffer, "%2d/%2d/%4d %2d:%2d:%2d AM",
								TIME->tm_mon,TIME->tm_mday,TIME->tm_year+1900,
								TIME->tm_hour,TIME->tm_min,TIME->tm_sec);
						write(cli_fd, buffer, strlen(buffer));
					}else{
						sprintf(buffer, "%2d/%2d/%4d %2d:%2d:%2d PM",TIME->tm_mon,
								TIME->tm_mday,TIME->tm_year+1900,(TIME->tm_hour)-12,
								TIME->tm_min,TIME->tm_sec);
						write(cli_fd, buffer, strlen(buffer));
					}



				}else{
					sprintf(buffer, "Invalid");
					write(cli_fd, buffer, n);
				}


			}
			close(cli_fd);
			//Release semaphore to indicate that this task is now free
			OSSemPost(&nTasksSem);
		}

}


void UserMain(void * pd) {
    InitializeStack();
    OSChangePrio(MAIN_PRIO);
    EnableAutoUpdate();
    int lis_fd, cli_fd;

    iprintf("Application started\n");
    OSTaskCreate(ServerCode, (void *)0, &TS[0][TSZ], &TS[0][0], MAIN_PRIO+1);
    lis_fd = listen(INADDR_ANY, HTONS(100), 5);

    OSSemInit(&nTasksSem, 4);
    OSQInit(&fdQueue, (void **) QData,4);

    struct tm time;
    TIME=&time;

    while(1){
        	//check semaphore to see if a task is free
        	OSSemPend(&nTasksSem, 0);

        	iprintf("waiting on client\n");
        	cli_fd=accept(lis_fd, NULL,NULL,0);
        	iprintf("Client accepted\n");

        	//push cli_fd onto fifo
        	OSQPost(&fdQueue, (void*) cli_fd);
        }

}
