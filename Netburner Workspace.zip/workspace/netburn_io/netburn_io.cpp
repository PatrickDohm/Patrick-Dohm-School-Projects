#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>
#include <ip.h>
#include <autoupdate.h>
#include<iosys.h>
#include <cstring>
#include<system.h>

extern "C" { void UserMain (void *pd); }
extern "C" {void printMenu();}



void printMenu(){
	char *string="1)Ticks per second\n";
	write(1, string, strlen(string));
	string="2)Maximum number of tasks\n";
	write(1, string, strlen(string));
	string="3)MAC address\n";
	write(1, string, strlen(string));
	string="4)Netmask\n";
	write(1, string, strlen(string));
	string="5)Gateway IP address\n";
	write(1, string, strlen(string));
	string = "6)IP address\n";
	write(1, string, strlen(string));
	string="\n";
	write(1, string, strlen(string));
	string="Selection:\n";
	write(1, string, strlen(string));
}


void UserMain (void *pd)
{
	InitializeStack();
	EnableAutoUpdate();



  OSChangePrio (MAIN_PRIO);

  int n;
  char string[10];

  iprintf ("Application started\n");
  while(1){
	  char* response="                                 \n";
	  strcpy(response,"");
	  printMenu();
	  n=read(0, string, 9);
	  char a=(char)string[0];
	  if(a=='1'){
		   n=TICKS_PER_SECOND;
		 sprintf(response, "%d\n",n);
		 write(1, response, 3);
	  }else if(a=='2'){
		  n=OS_MAX_TASKS;
		  sprintf(response, "%d\n", n);
		  write(1, response, 3);
	  }else if(a=='3'){
		 unsigned char a=gConfigRec.mac_address[0];
		 unsigned char b=gConfigRec.mac_address[1];
		 unsigned char c=gConfigRec.mac_address[2];
		 unsigned char d=gConfigRec.mac_address[3];
		 unsigned char e=gConfigRec.mac_address[4];
		 unsigned char f=gConfigRec.mac_address[5];
		 sprintf(response, "%x:%x:%x:%x:%x:%x\n", a,b,c,d,e,f);
		 write(1, response,strlen(response));
	  }else if(a=='4'){
		  long b=gConfigRec.ip_Mask;
		  unsigned char bytes[4];
		  bytes[0]= b&0xFF;
		  bytes[1]=(b>>8)&0xFF;
		  bytes[2]=(b>>16)&0xFF;
		  bytes[3]=(b>>24)&0xFF;
		  sprintf(response, "%d.%d.%d.%d\n", bytes[3],bytes[2],bytes[1],bytes[0]);
		  write(1,response,strlen(response));
	  }else if (a=='5'){
		  long c= gConfigRec.ip_GateWay;
		  unsigned char bytes[4];
		  bytes[0]= c&0xFF;
		  bytes[1]=(c>>8)&0xFF;
		  bytes[2]=(c>>16)&0xFF;
		  bytes[3]=(c>>24)&0xFF;
		  sprintf(response, "%d.%d.%d.%d\n", bytes[3],bytes[2],bytes[1],bytes[0]);
		  write(1,response,strlen(response)-26);
	  }else if(a=='6'){
		  long f=gConfigRec.ip_Addr;
		  unsigned char bytes[4];
		  bytes[0]= f&0xFF;
		  bytes[1]=(f>>8)&0xFF;
		  bytes[2]=(f>>16)&0xFF;
		  bytes[3]=(f>>24)&0xFF;
		  sprintf(response, "%d.%d.%d.%d\n", bytes[3],bytes[2],bytes[1],bytes[0]);
		  write(1,response,strlen(response));

	  }else{
		  response="Invalid Response\n";
		  write(1, response, strlen(response));
	  }
  }




}



