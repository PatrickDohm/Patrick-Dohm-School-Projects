#include "predef.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <startnet.h>
#include <autoupdate.h>
#include <ip.h>
#include <tcp.h>
#include <string.h>

extern "C" { void UserMain(void * pd); }

const int TCP_PORT = 2000;

const int BUF_SIZE = 256;
char buffer[BUF_SIZE];

char *IP_to_str(int IP, char *buffer)
{
	union {int IP; unsigned char b[sizeof(int)];} ipu;
	ipu.IP = IP;
	siprintf(buffer, "%d.%d.%d.%d", ipu.b[0], ipu.b[1], ipu.b[2], ipu.b[3]);
	return buffer;
}

void UserMain(void * pd) {
	int lst_fd, n, nfd, fd;
    InitializeStack();
    OSChangePrio(MAIN_PRIO);
    EnableAutoUpdate();

    lst_fd = listen(INADDR_ANY, HTONS(TCP_PORT), 5);

    IP_to_str(gConfigRec.ip_Addr, buffer);
    iprintf("SelectServer: Listening on port %s:%d\n", buffer, TCP_PORT);

    fd_set readfds, testrfds;
    fd_set testefds;
    FD_ZERO(&readfds);
   	FD_SET(lst_fd, &readfds);
    while (1) {
    	testrfds = readfds;
    	testefds = readfds;
    	n = select(FD_SETSIZE, &testrfds, 0, &testefds, 0);
    	// Test for new client connection request.
    	if(FD_ISSET(lst_fd, &testrfds)) {
    		nfd = accept(lst_fd, 0, 0, 0);
    		iprintf("Accepting new client on fd %d\n", nfd);
    		FD_CLR(lst_fd, &testrfds);
    		FD_SET(nfd, &readfds);
    		n--;
    	} // end if
    	fd = 36;
    	while(n > 0 && fd >= 5) {
    	    // ADD CODE TO TEST IF FILE DESCRIPTOR fd IS READY TO
    	    // BE READ HERE.  READ THE DATA INTO buffer, CONVERT IT
    		// TO UPPERCASE AND WRITE THE DATA BACK TO fd.
    		if(FD_ISSET(fd, &testrfds)){
    			int nr;
    			nr=read(fd,buffer,BUF_SIZE);
    			strupr(buffer);
    			write(fd, buffer, nr);
    		}
    		if(FD_ISSET(fd, &testefds)) {
    			close(fd);
    			FD_CLR(fd, &readfds);
    			iprintf("Closing client on fd %d\n", fd);
    			n--;
    		}
    		fd--;
		} // END while (n > 0)
    }  // END while (1)
}
