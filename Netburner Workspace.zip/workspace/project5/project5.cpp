#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <ucos.h>
#include <utils.h>/*
 * project5.cpp
 *
 *  Created on: Mar 26, 2020
 *      Author: Patrick Dohm
 */
extern "C" { void UserMain(void * pd); }

const int BUFFER = 128;


OS_SEM sem_id;
OS_MBOX Mbox;
OS_FIFO mfifo;
typedef struct {
	void *ptr_fifo;   //  For use by uC/OS
	char msg[BUFFER];
} MyFifoEl;


DWORD TaskStacks[3][USER_TASK_STK_SIZE] __attribute__((aligned(4)));


//use fgets(char* buf, int n, FILE *fp) to get the line
//Threadb needs to show the uppercase message while debugging
//use strupper to make the string uppercase

void TaskCodeA(void *d)
{	/*Thread A should prompt the user to enter a single-line message. (The message may
include multiple words separated by white space.) It should then pass a pointer to the
message to Thread B via a mail box. */

	BYTE status;
	status=OSSemPost(&sem_id);
	if(status!=OS_NO_ERR){
		iprintf("Error posting semaphore outside  of while loop in task a\n");
		exit(1);
	}


	char str[BUFFER];
	while(1){
		status=OSSemPend(&sem_id,0);
		if(status!=OS_NO_ERR){
			iprintf("Error pending semaphore in TASK A\n");
		}

		iprintf("Enter a single line message\n");
		fgets(str, BUFFER, stdin);
		status=OSMboxPost(&Mbox, (void*) str);
		if(status!=OS_NO_ERR){
			iprintf("Error posting a message in TaskCodeA\n");
			exit(1);
		}
	}
}

void TaskCodeB(void *d)
{
/*Thread B should copy the string to another buffer
converting it to uppercase in the process.
Thread B should pass the uppercase string to Thread C via a FIFO.
*/
	BYTE status;
	MyFifoEl element;
	char* str;
	while(1){
		str=(char *)OSMboxPend(&Mbox, 0, &status);
		if(status!= OS_NO_ERR){
			iprintf("error getting message in TaskCodeB\n");
			exit(1);
		}

		str=strupr(str);




		siprintf(element.msg,str);
		status= OSFifoPost(&mfifo,(OS_FIFO_EL*)&element );
		if(status !=OS_NO_ERR){
			iprintf("error posting to FIFO in TASKCODEB\n");
			exit(1);
		}
	}


}


void TaskCodeC(void *d)
{/*Thread C should reverse the uppercase string in-place.
Thread C should then display the reversed, uppercase message on the display.
 After Thread C finishes displaying the message, thread A should prompt the user for another
message and the whole process is repeated.*/

	BYTE status;
	char msg[BUFFER];
	while(1){
		MyFifoEl *p_fel=(MyFifoEl *)OSFifoPend(&mfifo,0);

		strncpy(msg,p_fel->msg,BUFFER);


		//string reverse algorithm
		char temp;
		int length= strlen(msg)-1;
		int i;
		int k=length;

		for(i=0;i<=(length/2);i++){
			temp=msg[k];
			msg[k]=msg[i];
			msg[i]=temp;
			k--;
		}

		iprintf(msg);
		iprintf("\n");
		//release semaphore after it prints
		status=OSSemPost(&sem_id);
		if(status!=OS_NO_ERR){
			iprintf("error releasing semaphore in task c\n");
			exit(1);
		}
		}




}

void UserMain(void * pd)
{
    BYTE status;
    OSChangePrio(MAIN_PRIO);
    //creating TaskA
    status = OSTaskCreate(TaskCodeA, (void *)1,
    				&TaskStacks[0][USER_TASK_STK_SIZE],
    				&TaskStacks[0][0], MAIN_PRIO+1);
    if(status != OS_NO_ERR) {
    	iprintf("Error creating Task A\n");
    	exit(1);
    }

    //Creating TaskB
    status = OSTaskCreate(TaskCodeB, (void *)2,
    				&TaskStacks[1][USER_TASK_STK_SIZE],
    				&TaskStacks[1][0], MAIN_PRIO+2);
    if(status != OS_NO_ERR) {
		iprintf("Error creating Task B\n");
    	exit(1);
    }

    //Creating TaskC
	status = OSTaskCreate(TaskCodeC, (void *)2,
				&TaskStacks[2][USER_TASK_STK_SIZE],
				&TaskStacks[2][0], MAIN_PRIO+3);
	if(status != OS_NO_ERR) {
		iprintf("Error creating Task C\n");
		exit(1);
	}

	//Creating semaphore1
	status= OSSemInit(&sem_id, 0);
	if(status != OS_NO_ERR){
		iprintf("Error creating semaphore\n");
		exit(1);
	}

	//creating messagebox1
	status= OSMboxInit(&Mbox,NULL );
	if(status != OS_NO_ERR){
		iprintf("Error creating Message box\n");
		exit(1);
	}

	//creating FIFO
	status = OSFifoInit(&mfifo);
	if(status != OS_NO_ERR) {
		iprintf("Error initializing fifo\n");
		exit(1);
	}


	iprintf("Application Started\n");

}




