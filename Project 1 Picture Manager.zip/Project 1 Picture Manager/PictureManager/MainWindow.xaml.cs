﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace PictureManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string[] Filename = new string[20];
        DirectoryInfo dir1 = new DirectoryInfo("PictureDirectory");//starting directory
        FileInfo[] Images;
        List<String> imagesList = new List<String>();
        DirectoryInfo[] subdir;
        List<String> subList = new List<String>();
        
        public MainWindow()
        {
            InitializeComponent();
            Current_Directory.Text = dir1.FullName;//print the directory name to the textbox
            Update_Click(this, null);
        }

        private void getContentnames()
        {//adds new images and subdirectories
            imagesList.Clear();
            subList.Clear();
            Images = dir1.GetFiles("*.jpg");
            subdir=dir1.GetDirectories();
            for (int i = 0; i < Images.Length; i++)
            {
                imagesList.Add(Images[i].Name);
              
            }
            for(int i = 0; i < subdir.Length; i++)
            {
                subList.Add(subdir[i].Name);
            }

        }

        private void ShowNewFiles()
        {int x = 0;


            Stack_Column_1.Children.Clear();
            Stack_Column_2.Children.Clear();
            Stack_Column_3.Children.Clear();

            foreach (String each in subList)
            {
                
                System.Windows.Controls.Image img = new System.Windows.Controls.Image();
                img.Source = new BitmapImage(new Uri(dir1.FullName + "/folder.png", UriKind.RelativeOrAbsolute));
                img.Width = 100;
                img.Height = 60;
                TextBlock nameBlock = new TextBlock();
                nameBlock.Text = each;
                nameBlock.TextAlignment = TextAlignment.Center;
                //add the name and img of each folder to the GUI
                if (x == 0)
                {
                    Stack_Column_1.Children.Add(img);
                    Stack_Column_1.Children.Add(nameBlock);
                }else if (x == 1)
                {
                    Stack_Column_2.Children.Add(img);
                    Stack_Column_2.Children.Add(nameBlock);
                }
                else
                {
                    Stack_Column_3.Children.Add(img);
                    Stack_Column_3.Children.Add(nameBlock);
                }
                x++;
                if (x >= 3)
                {
                    x = 0;
                }

            }
            //add the name and img of each jpg to the GUI.
            foreach (String each in imagesList)
            {
                
                System.Windows.Controls.Image img = new System.Windows.Controls.Image();
                img.Source = new BitmapImage(new Uri(dir1.FullName +"/Image_ICON.png", UriKind.RelativeOrAbsolute));
                img.Width = 100;
                img.Height = 60;
                TextBlock nameBlock = new TextBlock();
                nameBlock.Text = each;
                nameBlock.TextAlignment = TextAlignment.Center;
                if (x == 0)
                {
                    Stack_Column_1.Children.Add(img);
                    Stack_Column_1.Children.Add(nameBlock);
                }
                else if (x == 1)
                {
                    Stack_Column_2.Children.Add(img);
                    Stack_Column_2.Children.Add(nameBlock);
                }
                else
                {
                    Stack_Column_3.Children.Add(img);
                    Stack_Column_3.Children.Add(nameBlock);
                }
                x++;
                if (x >= 3)
                    x = 0;

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)//creates subdirectory
        {
            Directory.CreateDirectory(dir1.FullName + "/" + Enter_Sub_Name.Text);
            Button_Click_1(this, null);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//sorts photos into sub
        {
            foreach(String each in subList)
            {
                foreach(String img in imagesList)
                {
                  
                    if (img.Contains(each))
                    {
                        System.IO.File.Move(dir1.FullName+"/"+img, dir1.FullName+"/"+each +"/"+img);

                    }
                }
            }
            Update_Click(this, null);
        }

        private void Open_File_Click(object sender, RoutedEventArgs e)
        {
            
            Process.Start(dir1.FullName + "/"+File_Name.Text );
        }

        private void Delete_File_Click(object sender, RoutedEventArgs e)
        {
            if (File_Name.Text.Contains(".jpg"))
            {System.IO.File.Delete(dir1.FullName+"/"+File_Name.Text);

            }
            else
            {
                System.IO.Directory.Delete(dir1.FullName + "/" + File_Name.Text);
            }
            Update_Click(this, null);
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            getContentnames();
            ShowNewFiles();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            System.IO.File.Move(dir1.FullName + "/" + Moved_File.Text, dir1.FullName + "/" + Destination.Text + "/" + Moved_File.Text);
            Update_Click(this, null);
        }
    }
}

