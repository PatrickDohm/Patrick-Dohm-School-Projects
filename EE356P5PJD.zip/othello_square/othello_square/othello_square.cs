﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace othello_square_class
{
    [Serializable]
    public class othello_square
    {
        private char piece;
        private bool taken;
        private bool Out_of_bounds;


        public othello_square()
        {
            piece = '\0';
            taken = false;
            Out_of_bounds = false;
        }

        public void SetPiece(char a)
        {
            piece = a;
        }
        public void SetTaken()
        {
            taken = true;
        }

        public bool IsTaken()
        {
            if (taken == true)
            {
                return true;
            }
            else { return false; }
        }
        public char CheckPiece()
        {
            return piece;
        }
        public bool IsOutOfBounds()
        {
            if (Out_of_bounds == false)
            {
                return false;
            }
            return true;
        }

        public void SetOutOfBounds()
        {
            Out_of_bounds = true;
        }
    }
}
