﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.ComponentModel;
using othello_square_class;
using othello_board_class;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace OthelloServer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        delegate void SetTextCallback(String text);


        public MainWindow()
        {
            InitializeComponent();
        }

        BackgroundWorker backgroundWorker1 = new BackgroundWorker();
        othello_board board = new othello_board(); //this is the gameboard
        delegate void Draw_Img(othello_board board);
        //limit the program to 5 clients at a time
        BackgroundWorker[] bkw1 = new BackgroundWorker[5];
        Socket client;
        NetworkStream[] ns = new NetworkStream[5];
        StreamReader[] sr = new StreamReader[5];
        StreamWriter[] sw = new StreamWriter[5];
        List<int> AvailableClientNumbers = new List<int>(5);
        List<int> UsedClientNumbers = new List<int>(5);



        int clientcount = 0;

        private void SerializeNow(int t)
        {

            BinaryFormatter b = new BinaryFormatter();
            MemoryStream serializeIt = new MemoryStream();
            b.Serialize(serializeIt, board);
            Thread.Sleep(1000);
            //foreach (int t in UsedClientNumbers)//sends to each client
            //{ 
            serializeIt.Position = 0;
            sw[t].WriteLine(serializeIt.Length.ToString());
            sw[t].Flush();
            sw[t].BaseStream.Write(serializeIt.GetBuffer(), 0, Convert.ToInt32(serializeIt.Length));
            sw[t].Flush();
            Thread.Sleep(500);
            //}



        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            TcpListener newsocket = new TcpListener(IPAddress.Any, 11899);
            newsocket.Start();

            for (int i = 0; i < 5; i++)
            {
                AvailableClientNumbers.Add(i);
            }
            while (AvailableClientNumbers.Count > 0)//waits for people to connect
            {
                InsertText("waiting for client");
                client = newsocket.AcceptSocket();//accept connection
                clientcount = AvailableClientNumbers.First();
                AvailableClientNumbers.Remove(clientcount);
                ns[clientcount] = new NetworkStream(client);
                sr[clientcount] = new StreamReader(ns[clientcount]);
                sw[clientcount] = new StreamWriter(ns[clientcount]);

                if (clientcount == 0)
                {
                    sw[clientcount].WriteLine("x");
                    sw[clientcount].Flush();

                }
                else if (clientcount == 1)
                {
                    sw[clientcount].WriteLine("o");
                    sw[clientcount].Flush();
                }
                else
                {
                    sw[clientcount].WriteLine("\0");
                    sw[clientcount].Flush();
                }

                bkw1[clientcount] = new BackgroundWorker();
                bkw1[clientcount].DoWork += new DoWorkEventHandler(client_DoWork);
                bkw1[clientcount].RunWorkerAsync(clientcount);
                UsedClientNumbers.Add(clientcount);


            }
        }

        private void client_DoWork(object sender, DoWorkEventArgs e)
        {
            int clientnum = (int)e.Argument;
            bkw1[clientnum].WorkerSupportsCancellation = true;
            othello_board board = new othello_board();
            if (clientnum <= 1)//only player 0 and 1 can play
            {
                SerializeNow(clientnum);
                while (true)
                {

                    // try
                    // {




                    //send board to player


                    if (game_over() == true)
                    {
                        string a = who_won().ToString();
                        InsertText(a);
                        sr[clientnum].Close();
                        sw[clientnum].Close();
                        ns[clientnum].Close();
                        KillMe(clientnum);
                    }

                    //deserialize it
                    string inputstream = "";
                    inputstream = sr[clientnum].ReadLine();//wait for turn
                    int count = Convert.ToInt32(inputstream);
                    byte[] buffer = new byte[count];
                    sr[clientnum].BaseStream.Read(buffer, 0, count);
                    MemoryStream serialIt = new MemoryStream(buffer);

                    BinaryFormatter b = new BinaryFormatter();
                    board = (othello_board)b.Deserialize(serialIt);
                    //draw board
                    Draw_Board(board);
                    //check if the game is over

                    if (board.player_turn() == 'x')
                    {
                        board.Set_player_turn('o');
                        foreach (int t in UsedClientNumbers)
                        {
                            SerializeNow(t);
                        }
                    }
                    else
                    {
                        board.Set_player_turn('x');
                        foreach (int t in UsedClientNumbers)
                        {
                            SerializeNow(clientnum);

                        }

                    }


                    //  }




                    // catch
                    //{
                    //sr[clientnum].Close();
                    //sw[clientnum].Close();
                    //ns[clientnum].Close();
                    //KillMe(clientnum);

                    //}

                }


            }

        }

        private void InsertText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.listBox1.Dispatcher.CheckAccess())
            {
                this.listBox1.Items.Insert(0, text);

            }
            else
            {
                listBox1.Dispatcher.BeginInvoke(new SetTextCallback(InsertText), text);
            }
        }

        private void KillMe(int threadnum)
        {

            UsedClientNumbers.Remove(threadnum);
            AvailableClientNumbers.Add(threadnum);
            bkw1[threadnum].CancelAsync();
            bkw1[threadnum].Dispose();
            bkw1[threadnum] = null;
            GC.Collect();
        }

        private void Start_Server_Btn_Click(object sender, RoutedEventArgs e)
        {

            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            backgroundWorker1.RunWorkerAsync("Message to Worker");


        }


        private void Draw_Board(othello_board board)
        {
            if (this.Grid_Img.Dispatcher.CheckAccess())
            {
                Pen blackpen = new Pen(Brushes.Black, 1);//This pen will be used to draw the board
                Pen xpen = new Pen(Brushes.Blue, 1);//this pen will be used to draw the x's
                Pen open = new Pen(Brushes.Red, 1);//this pen will be used to draw the o's
                Pen possible = new Pen(Brushes.Green, 1);
                DrawingVisual vis = new DrawingVisual(); //create new drawing visual
                DrawingContext dc = vis.RenderOpen();// create drawing context

                //draw grid
                //vertical lines
                dc.DrawLine(blackpen, new Point(0, 0), new Point(0, 288));
                dc.DrawLine(blackpen, new Point(36, 0), new Point(36, 288));
                dc.DrawLine(blackpen, new Point(72, 0), new Point(72, 288));
                dc.DrawLine(blackpen, new Point(108, 0), new Point(108, 288));
                dc.DrawLine(blackpen, new Point(144, 0), new Point(144, 288));
                dc.DrawLine(blackpen, new Point(180, 0), new Point(180, 288));
                dc.DrawLine(blackpen, new Point(216, 0), new Point(216, 288));
                dc.DrawLine(blackpen, new Point(252, 0), new Point(252, 288));
                dc.DrawLine(blackpen, new Point(288, 0), new Point(288, 288));

                //horizontal
                dc.DrawLine(blackpen, new Point(0, 0), new Point(288, 0));
                dc.DrawLine(blackpen, new Point(0, 36), new Point(288, 36));
                dc.DrawLine(blackpen, new Point(0, 72), new Point(288, 72));
                dc.DrawLine(blackpen, new Point(0, 108), new Point(288, 108));
                dc.DrawLine(blackpen, new Point(0, 144), new Point(288, 144));
                dc.DrawLine(blackpen, new Point(0, 180), new Point(288, 180));
                dc.DrawLine(blackpen, new Point(0, 216), new Point(288, 216));
                dc.DrawLine(blackpen, new Point(0, 252), new Point(288, 252));
                dc.DrawLine(blackpen, new Point(0, 288), new Point(288, 288));


                //Draw xs and os



                //Draw A
                //Draw A1
                int center_y = 18;  //these variables are different at A,B,C....
                int y1 = 1;
                int y2 = 35;
                if (board.Check_node(1, 1).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 1).CheckPiece() == 'o')   //draw an o in A1
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw A2
                if (board.Check_node(2, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw A3
                if (board.Check_node(3, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw A4
                if (board.Check_node(4, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw A5
                if (board.Check_node(5, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw A6
                if (board.Check_node(6, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw A7
                if (board.Check_node(7, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw A8
                if (board.Check_node(8, 1).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 1).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 1, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }





                //Draw B
                center_y = 54;
                y1 = 37;
                y2 = 71;
                //Draw B1
                if (board.Check_node(1, 2).CheckPiece() == 'x')//draw an x in B1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw B2
                if (board.Check_node(2, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw B3
                if (board.Check_node(3, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw B4
                if (board.Check_node(4, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw B5
                if (board.Check_node(5, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw B6
                if (board.Check_node(6, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw B7
                if (board.Check_node(7, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw B8
                if (board.Check_node(8, 2).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 2).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 2, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }




                //Draw C
                center_y = 90;
                y1 = 73;
                y2 = 107;
                //Draw C1
                if (board.Check_node(1, 3).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }


                //Draw C2
                if (board.Check_node(2, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw C3
                if (board.Check_node(3, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw C4
                if (board.Check_node(4, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw C5
                if (board.Check_node(5, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw C6
                if (board.Check_node(6, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw C7
                if (board.Check_node(7, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw C8
                if (board.Check_node(8, 3).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 3).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 3, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }


                //Draw D
                center_y = 126;
                y1 = 109;
                y2 = 143;
                //Draw D1
                if (board.Check_node(1, 4).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw D2
                if (board.Check_node(2, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw D3
                if (board.Check_node(3, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw D4
                if (board.Check_node(4, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw D5
                if (board.Check_node(5, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw D6
                if (board.Check_node(6, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw D7
                if (board.Check_node(7, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw D8
                if (board.Check_node(8, 4).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 4).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 4, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }



                //Draw E
                center_y = 162;
                y1 = 145;
                y2 = 179;
                //Draw E1
                if (board.Check_node(1, 5).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw E2
                if (board.Check_node(2, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw E3
                if (board.Check_node(3, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw E4
                if (board.Check_node(4, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw E5
                if (board.Check_node(5, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw E6
                if (board.Check_node(6, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw E7
                if (board.Check_node(7, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw E8
                if (board.Check_node(8, 5).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 5).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 5, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }



                //Draw F
                center_y = 198;
                y1 = 181;
                y2 = 215;
                //Draw F1
                if (board.Check_node(1, 6).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw F2
                if (board.Check_node(2, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw F3
                if (board.Check_node(3, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw F4
                if (board.Check_node(4, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw F5
                if (board.Check_node(5, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw F6
                if (board.Check_node(6, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw F7
                if (board.Check_node(7, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw F8
                if (board.Check_node(8, 6).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 6).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 6, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }



                //Draw G
                center_y = 234;
                y1 = 217;
                y2 = 251;
                //Draw G1
                if (board.Check_node(1, 7).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw G2
                if (board.Check_node(2, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw G3
                if (board.Check_node(3, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw G4
                if (board.Check_node(4, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw G5
                if (board.Check_node(5, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw G6
                if (board.Check_node(6, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw G7
                if (board.Check_node(7, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw G8
                if (board.Check_node(8, 7).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 7).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 7, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }



                //Draw H
                center_y = 270;
                y1 = 253;
                y2 = 288;
                //Draw H1
                if (board.Check_node(1, 8).CheckPiece() == 'x')//draw an x in A1
                {
                    dc.DrawLine(xpen, new Point(1, y1), new Point(35, y2));
                    dc.DrawLine(xpen, new Point(1, y2), new Point(35, y1));
                }
                else if (board.Check_node(1, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(18, center_y), 8, 8);
                }
                else if (board.Check_Playability(1, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(18, center_y), 8, 8);
                }

                //Draw H2
                if (board.Check_node(2, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(37, y1), new Point(71, y2));
                    dc.DrawLine(xpen, new Point(37, y2), new Point(71, y1));
                }
                else if (board.Check_node(2, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(54, center_y), 8, 8);
                }
                else if (board.Check_Playability(2, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(54, center_y), 8, 8);
                }

                //Draw H3
                if (board.Check_node(3, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(73, y1), new Point(107, y2));
                    dc.DrawLine(xpen, new Point(73, y2), new Point(107, y1));
                }
                else if (board.Check_node(3, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(90, center_y), 8, 8);
                }
                else if (board.Check_Playability(3, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(90, center_y), 8, 8);
                }

                //Draw H4
                if (board.Check_node(4, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(109, y1), new Point(143, y2));
                    dc.DrawLine(xpen, new Point(109, y2), new Point(143, y1));
                }
                else if (board.Check_node(4, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(126, center_y), 8, 8);
                }
                else if (board.Check_Playability(4, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(126, center_y), 8, 8);
                }

                //Draw H5
                if (board.Check_node(5, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(145, y1), new Point(179, y2));
                    dc.DrawLine(xpen, new Point(145, y2), new Point(179, y1));
                }
                else if (board.Check_node(5, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(162, center_y), 8, 8);
                }
                else if (board.Check_Playability(5, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(162, center_y), 8, 8);
                }

                //Draw H6
                if (board.Check_node(6, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(181, y1), new Point(215, y2));
                    dc.DrawLine(xpen, new Point(181, y2), new Point(215, y1));
                }
                else if (board.Check_node(6, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(198, center_y), 8, 8);
                }
                else if (board.Check_Playability(6, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(198, center_y), 8, 8);
                }

                //Draw H7
                if (board.Check_node(7, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(217, y1), new Point(251, y2));
                    dc.DrawLine(xpen, new Point(217, y2), new Point(251, y1));
                }
                else if (board.Check_node(7, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(234, center_y), 8, 8);
                }
                else if (board.Check_Playability(7, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(234, center_y), 8, 8);
                }

                //Draw H8
                if (board.Check_node(8, 8).CheckPiece() == 'x')
                {
                    dc.DrawLine(xpen, new Point(252, y1), new Point(287, y2));
                    dc.DrawLine(xpen, new Point(252, y2), new Point(287, y1));
                }
                else if (board.Check_node(8, 8).CheckPiece() == 'o')
                {
                    dc.DrawEllipse(null, open, new Point(270, center_y), 8, 8);
                }
                else if (board.Check_Playability(8, 8, board.player_turn()))
                {   //draw a green circle if the move is possible
                    dc.DrawEllipse(null, possible, new Point(270, center_y), 8, 8);
                }


                dc.Close();

                RenderTargetBitmap wbmap = new RenderTargetBitmap(288, 288, 100, 100, PixelFormats.Pbgra32);
                wbmap.Render(vis);


                Grid_Img.Source = wbmap;    //prints the entire grid at once

            }
            else
            {
                Grid_Img.Dispatcher.BeginInvoke(new Draw_Img(Draw_Board), board);//uses delegate to print the board
            }






        }


        private bool game_over()
        {


            for (int i = 0; i <= 9; i++)
            {
                for (int j = 0; j <= 9; j++)
                {
                    //check if there are any possible moves left, if there are return false
                    if (board.check_up(i, j, 'x')) { return false; }
                    else if (board.check_up(i, j, 'o')) { return false; }
                    else if (board.check_down(i, j, 'x')) { return false; }
                    else if (board.check_down(i, j, 'o')) { return false; }
                    else if (board.check_left(i, j, 'x')) { return false; }
                    else if (board.check_left(i, j, 'o')) { return false; }
                    else if (board.check_right(i, j, 'x')) { return false; }
                    else if (board.check_right(i, j, 'o')) { return false; }
                    else if (board.check_up_diagonal_left(i, j, 'x')) { return false; }
                    else if (board.check_up_diagonal_left(i, j, 'o')) { return false; }
                    else if (board.check_up_diagonal_right(i, j, 'x')) { return false; }
                    else if (board.check_up_diagonal_right(i, j, 'o')) { return false; }
                    else if (board.check_down_diagonal_left(i, j, 'x')) { return false; }
                    else if (board.check_down_diagonal_left(i, j, 'o')) { return false; }
                    else if (board.check_down_diagonal_right(i, j, 'x')) { return false; }
                    else if (board.check_down_diagonal_right(i, j, 'o')) { return false; }

                }
            }
            //if it passes all these tests then the game is over
            return true;
        }


        private char who_won()//called when game_over()==true
        {
            int xcount = 0;
            int ocount = 0;
            for (int i = 0; i <= 9; i++)
            {
                for (int j = 0; j <= 9; j++)
                {
                    if (board.Check_node(i, j).CheckPiece() == 'x')
                    {
                        xcount++;
                    }
                    else if (board.Check_node(i, j).CheckPiece() == 'o')
                    {
                        ocount++;
                    }
                }
            }

            if (xcount > ocount)
            {
                return 'x';
            }
            else
            {
                return 'o';
            }

        }
    }
}
