﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using othello_square_class;

namespace othello_board_class
{
    [Serializable]
    public class othello_board
    {
        private othello_square[,] board_set = new othello_square[10, 10];//This is the gameboard
        private char player;

        public othello_board()
        {
            int x, y;
            
            for (x = 0; x <= 9; x++)
            {
                for (y = 0; y <= 9; y++)
                {
                    board_set[x, y] = new othello_square(); //initialize each square
                }
            }


            for (x = 0; x < 9; x++)
            {
                board_set[x, 0].SetOutOfBounds();   //set up out of bounds for the board
            }
            for (x = 0; x < 9; x++)
            {
                board_set[x, 9].SetOutOfBounds();   //set up out of bounds for the board
            }

            for (y = 0; y < 9; y++)
            {
                board_set[0, y].SetOutOfBounds();   //set up out of bounds for the board
            }
            for (y = 0; y < 9; y++)
            {
                board_set[9, y].SetOutOfBounds();   //set up out of bounds for the board
            }

            //set initial turn to x
            player = 'x';

            //set initial board
            //xo
            //ox
            Check_node(4, 4).SetPiece('x');
            Check_node(5, 4).SetPiece('o');
            Check_node(5, 5).SetPiece('x');
            Check_node(4, 5).SetPiece('o');

            Check_node(4, 4).SetTaken();
            Check_node(4, 5).SetTaken();
            Check_node(5, 4).SetTaken();
            Check_node(5, 5).SetTaken();


        }

        public othello_square Check_node(int a, int b)
        {
            return board_set[a, b];
        }
        public char player_turn()
        {
            return player;
        }
        public void Set_player_turn(char turn)
        {
            player = turn;
        }

        public bool Check_Playability(int a, int b, char player)//calls all the check functions
        {
            if (check_up(a, b, player) == true){return true;}
            if (check_down(a, b, player) == true){return true;}
            if (check_left(a, b, player) == true) { return true; }
            if (check_right(a, b, player) == true) { return true; }
            if (check_up_diagonal_left(a, b, player)) { return true; }
            if (check_up_diagonal_right(a, b, player)) { return true; }
            if (check_down_diagonal_left(a, b, player)) { return true; }
            if (check_down_diagonal_right(a, b, player)) { return true; }
            return false;
        }
      
        //these functions will tell the computer if there is a legal move on the square
        public bool check_up( int a, int b, char player)//call this fuction for all non taken squares
        {
            //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a, b - 1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a, b - 1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }
           



            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential
            {
                return check_up(a, b - 1, player);
            }else if (board_set[a, b - 1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_up( a, b - 1, player);
            }
            return false;
        }



        public bool check_down( int a, int b, char player)//call this function for all nontaken squares
        {   //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a, b + 1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a, b + 1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_down( a, b + 1, player);
            }
            else if (board_set[a, b - 1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_down( a, b + 1, player);
            }

            return false;
        }



        public bool check_left( int a, int b, char player)
        {//base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a-1, b].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a-1, b].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_left( a-1, b, player);
            }
            else if (board_set[a-1, b].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_left( a-1, b, player);
            }

            return false;

        }


        public bool check_right( int a, int b, char player)
        {
            //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a + 1, b].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a + 1, b].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_right( a + 1, b, player);
            }
            else if (board_set[a + 1, b].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_right( a + 1, b, player);
            }

            return false;

        }


        public bool check_up_diagonal_right(int a, int b, char player)
        { //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a + 1, b-1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a + 1, b-1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_up_diagonal_right(a + 1, b-1, player);
            }
            else if (board_set[a + 1, b-1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_up_diagonal_right(a + 1, b-1, player);
            }

            return false;

        }


        public bool check_up_diagonal_left(int a, int b, char player)
        { //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a - 1, b - 1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a - 1, b - 1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_up_diagonal_left(a - 1, b - 1, player);
            }
            else if (board_set[a - 1, b - 1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_up_diagonal_left(a - 1, b - 1, player);
            }

            return false;

        }

        public bool check_down_diagonal_right(int a, int b, char player)
        {//base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a + 1, b + 1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a + 1, b + 1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_down_diagonal_right(a + 1, b + 1, player);
            }
            else if (board_set[a + 1, b + 1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_down_diagonal_right(a + 1, b + 1, player);
            }

            return false;

        }
        


        public bool check_down_diagonal_left(int a, int b, char player)
        {
            //base case
            if (board_set[a, b].IsOutOfBounds())
            {
                return false;
            }
            if (board_set[a, b].IsTaken() == true && board_set[a, b].CheckPiece() != player && board_set[a - 1, b + 1].CheckPiece() == player)//the current square is taken, the current square is different from the players square, and the square above it is the player's square
            {
                return true;
            }
            if (board_set[a - 1, b + 1].IsTaken() == false)//if the square above it is false
            {
                return false;
            }


            //recursive case
            if (board_set[a, b].IsTaken() == false)//if the space is not taken and the one above it is taken, recursivily call check_up to see if it has potential (already checked if the one above it is taken in base case)
            {
                return check_down_diagonal_left(a - 1, b + 1, player);
            }
            else if (board_set[a - 1, b + 1].CheckPiece() != player)// if the piece above is the opposite player, recursivly call check_up
            {
                return check_down_diagonal_left(a - 1, b + 1, player);
            }

            return false;
        }







        //Functions to flip pieces, call them on areas that return true after placing a piece
        public void flip_up(int a, int b, char player)//flips pieces from the starting point going up
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if(board_set[a,b-1].CheckPiece()!=player && board_set[a, b - 1].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                 flip_up(a, b - 1, player);
            }
        }

        public void flip_down(int a, int b, char player)
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a, b + 1].CheckPiece() != player && board_set[a, b + 1].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_down(a, b + 1, player);
            }
        }


        public void flip_left(int a, int b, char player)
        { //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a-1, b].CheckPiece() != player && board_set[a-1, b].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_left(a-1, b, player);
            }

        }



        public void flip_right(int a, int b, char player)
        {//flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a + 1, b].CheckPiece() != player && board_set[a + 1, b].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_right(a + 1, b, player);
            }

        }

        public void flip_diagonal_up_left(int a, int b, char player)
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a - 1, b-1].CheckPiece() != player && board_set[a - 1, b-1].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_diagonal_up_left(a - 1, b-1, player);
            }
        }

        public void flip_diagonal_up_right(int a, int b, char player)
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a + 1, b-1].CheckPiece() != player && board_set[a + 1, b-1].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_diagonal_up_right(a + 1, b-1, player);
            }
        }

        public void flip_diagonal_down_left(int a, int b, char player)
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a - 1, b+1].CheckPiece() != player && board_set[a - 1, b].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_diagonal_down_left(a - 1, b, player);
            }
        }

        public void flip_diagonal_down_right(int a, int b, char player)
        {
            //flip current piece
            board_set[a, b].SetPiece(player);

            if (board_set[a - 1, b].CheckPiece() != player && board_set[a - 1, b].IsOutOfBounds() == false)   //if the piece above if does is not the players piece, recursivly call flip up on that piece.
            {   //the bounds checking is probably unneccesary because i check the bounds of the possible moves functions
                flip_diagonal_down_right(a - 1, b, player);
            }
        }


    }
}
