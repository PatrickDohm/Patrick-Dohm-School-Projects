class SettingsController < ApplicationController

    def create 
        @setting = Setting.create(setting_params)
    end

    def new
        @setting = Setting.new
    end

    private
    def setting_params
        params.require(:settings).permit(:Quarantine)
    end

end
