module CloseContactHelper
end
