module SettingHelper
end
