require 'rails_helper'

RSpec.feature "UserSearch", type: :feature do
  before :each do        
    @user = create(:user,username: 'USERNAME', password: 'PASSWORD')
    create(:user, first_name: 'Rodney', last_name: 'Okanya', cellphone: '555-1212' )
    visit '/login'
    fill_in "Username", :with=> "USERNAME"
    fill_in "Password", :with=> "PASSWORD"
    click_button "Login"
  end
    scenario "User Searches by Number" do
        expect(page).to have_text("You are logged in")
    fill_in "Search", :with=> "555-1212"
    click_button "Search"
    expect(page).to have_text("Rodney")
  end

  scenario "User Searches by First Name" do
    expect(page).to have_text("You are logged in")
    fill_in "Search", :with=> "Rodney"
    click_button "Search"
    expect(page).to have_text("555-1212")
  end

  scenario "User Searches by last name" do
    expect(page).to have_text("You are logged in")
    fill_in "Search", :with=>"Okanya"
    click_button "Search"
    expect(page).to have_text("555-1212")
  end
end

