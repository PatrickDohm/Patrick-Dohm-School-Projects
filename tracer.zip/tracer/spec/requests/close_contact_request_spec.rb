require 'rails_helper'

RSpec.describe "CloseContacts", type: :request do

end
