require 'rails_helper'

RSpec.describe "Settings", type: :request do

end
