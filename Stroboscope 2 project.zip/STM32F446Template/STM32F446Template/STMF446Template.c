#include "stm32f446.h"

const char ASCII []="0123456789";
void ConfigureUSART(unsigned int baudDivisor);
void USARTPutChar(char ch);
void SendMsg(const char msg[]);
void ConvertRPM2String(int f, char s[]);
void ConvertDuty2String(int f, char p[]);
void ClockSetUp(void);
void GPIOSetUp(void);
void TimerSetUp(void);
void ADCSetUp(void);

int main(void){
	int tmp,i,j;
	int freq, rpm, duty_cycle;
	char s[13];
	char p[6];
	
	ClockSetUp();
	GPIOSetUp();
	TimerSetUp();
	ADCSetUp();
	ConfigureUSART(0xD05);
	
	TIM3_CCR1=TIM3_ARR/2;//Start Duty cycle at 50%
	while(1){
		
		//ADC1 is PA5 and controls the rpm
		ADC1_CR2 |=0x40000000; //bit 30 does software start of A/D Conversion
		while((ADC1_SR &0x2)==0);	//bit 1 is the end of conversion
		TIM3_ARR=ADC1_DR & 0xFFF;
		freq=(int)(16000000/TIM3_ARR);
		rpm=freq*60;
		ConvertRPM2String(rpm, s);
		SendMsg(s);
		
		
		//ADC is PC0 and controls the duty cycle
		ADC2_CR2 |=0x40000000; //bit 30 does software start of A/D Conversion
		while((ADC2_SR &0x2) == 0);
		int i = (ADC2_DR & 0xFFF)/5; 
		TIM3_CCR1=	;//FIX HERE
	}
}//end of main program

void ConvertRPM2String(int f, char s[]){
	char d0, d1, d2,d3,d4,d5;
	d0=f%10;f=f/10;
	d1=f%10;f=f/10;
	d2=f%10;f=f/10;
	d3=f%10;f=f/10;
	d5=f%10;
	s[0]='/';
	s[1]=' ';
	s[2]=ASCII[d5];
	s[3]=ASCII[d4];
	s[4]=ASCII[d3];
	s[5]=ASCII[d2];
	s[6]=ASCII[d1];
	s[7]=ASCII[d0];
	s[8]=' ';
	s[9]='R';
	s[10]='P';
	s[11]='M';
	s[12]='\0';
	}
void ConvertDuty2String(int f, char p[]){
	char d0, d1, d2;
	f=f*10;
	d0=f%10;f=f/10;
	d1=f%10;f=f/10;
	d2=f%10; 
	
	p[0]=' ';
	p[1]=ASCII[d2];
	p[2]=ASCII[d1];
	p[3]='.';
	p[4]=ASCII[d0];
	p[5]='%';
}
void ConfigureUSART(unsigned int baudDivisor){
USART6_CR1=0;
USART6_BRR=baudDivisor;
USART6_CR2=0;
USART6_CR1=0x200C;
USART6_CR3=0;
}

void USARTPutChar(char ch){
	//wait for empty flag
	while((USART6_SR &0x80)==0);
	USART6_DR=ch;
}

void SendMsg(const char msg[]){
int i=0;
while(msg[i]!=0){
	USARTPutChar(msg[i]);
	i++;
}
}

void ClockSetUp(void){
	//clock bits
	RCC_AHB1ENR |=4; //bit 2 is GPIOC clock enable
	RCC_APB1ENR |=2; //enable peripheral timer
	RCC_AHB1ENR |=1; //Bit 0 is GPIOA Clock Enable bit;
	RCC_APB2ENR |=0x100; //Bit 8 is ADC1 clock enable bit;
	RCC_AHB1ENR |=4; //bit 3 is GPIOC Clock enable bit
	RCC_APB2ENR |=(1<<5); // Enable USART6 Clock
}

void GPIOSetUp(void){
	//I/O bits
	GPIOA_MODER |=0x2000; //bits 13-12=10 for Alt Funct Mode on PA6
	//OTYPER register resets to 0 so it is push/pull by default
	GPIOA_OSPEEDER |= 0x3000; //Bits 13-12=11 for high speed on PA6
	//PUPDR defaults to no pull up no pull down
	//Timer 3 bits
	GPIOA_AFRL = 0x02000000; //Set PA6 to timer 3
	GPIOA_MODER |= 0xF00; //PA4-5 are analog
	GPIOA_PUPDR &= 0xFFFFF0FF; //Pins PA4 PA5 are no pull up and no pull down
	//USART PIN Bits
	GPIOC_AFRL = 0x88000000; //Alternate function on PC 6-7 to USART 6;
	GPIOC_MODER |= 0x0A000; //Bits 15-12 = 1010 for alt function on PC6,PC7
	//OTYPER register resets to 0 so it is push pull by default
	GPIOC_OSPEEDER |=0x3000; //Bits 7-6 =11 for high speed on pc6
	
	GPIOC_MODER |= 0x3; //PC0 is analog
}
void TimerSetUp(void){
	TIM3_CCMR1 |= 0x60; //Timer 3 in PWM mode bits 6,5,4 =110
	TIM3_CCMR1 |=0x0C; //Timer 3 preload enable and fast enable
	TIM3_CR1 |= (1<<7); //Auto reload is buffered
	TIM3_PSC =0; //Not using prescaling
	TIM3_ARR = 3906; //(16MHz)/ 3906= 4096 Hz
	TIM3_CCR1 =2000; //Duty cycle starts at 2000/4096;
	TIM3_CCER |= 1;	//compare and capture output enabled
	TIM3_EGR |=1;		//Enable Event
	TIM3_CR1 |= 1; //Enable Timer 3
}

void ADCSetUP(void){//Add in parts for other adc conversion
			//ADC bits
	ADC1_CR2 |=1; //Bit 0 turn ADC on
	ADC1_CR2 |=0x400; //Bit 10 allows EOC to be set after conversion
	ADC_CCR |=0x30000; //Bits 16 and 17=11 so clock divided by 8
	ADC1_SQR3 |=0x5; //Bits 4:0 are channel number for first conversion
	
	
	ADC2_CR2 |= 1;
	ADC2_CR2 |=0x400; 
	ADC_CCR |=0X30000;
	ADC2_SQR3 |= 0XA;	//channel 10
}
	
	
	